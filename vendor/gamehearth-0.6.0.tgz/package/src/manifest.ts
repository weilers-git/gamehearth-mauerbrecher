import {
  maxSoloStats,
  sdkVersion,
  validateCatalogSpec,
  validateOptionsSpec,
  validatePlayerCountSpec,
  type CatalogEntrySpec,
  type CatalogSpec,
  type OptionsSpec,
  type PlayerCountSpec,
  type StatSpec,
} from "@gamehearth/sdk/platform";
import { clientPathProblem } from "./client-files";

export const codeLicenses = [
  "MIT",
  "Apache-2.0",
  "BSD-2-Clause",
  "BSD-3-Clause",
  "ISC",
  "0BSD",
  "Zlib",
  "Unlicense",
  "MPL-2.0",
  "EUPL-1.2",
  "LGPL-3.0-only",
  "LGPL-3.0-or-later",
  "GPL-3.0-only",
  "GPL-3.0-or-later",
  "AGPL-3.0-only",
  "AGPL-3.0-or-later",
] as const;

export const assetLicenses = ["CC0-1.0", "CC-BY-4.0", "CC-BY-SA-4.0"] as const;
export const gameModes = ["single", "turn-based", "realtime"] as const;
export const roleNames = ["player", "screen", "controller"] as const;
export const inputKinds = ["touch", "keyboard", "mouse", "gamepad"] as const;
export const screenClasses = ["small", "medium", "large"] as const;
export const maxStats = maxSoloStats;

export type GameMode = (typeof gameModes)[number];
export type RoleName = (typeof roleNames)[number];
export type InputKind = (typeof inputKinds)[number];
export type ScreenClass = (typeof screenClasses)[number];

export type { StatSpec };

export interface RoleSpec {
  inputs: InputKind[];
  screen: ScreenClass;
}

export interface Manifest {
  id: string;
  name: string;
  version: string;
  sdk: string;
  license: { code: string; assets: string };
  mode: GameMode;
  players: PlayerCountSpec;
  server: boolean;
  client: string;
  roles: Partial<Record<RoleName, RoleSpec>>;
  description?: string;
  repository?: string;
  items?: Record<string, CatalogEntrySpec>;
  stats?: Record<string, StatSpec>;
  flags?: Record<string, CatalogEntrySpec>;
  options?: OptionsSpec;
}

export function catalogOf(manifest: Pick<Manifest, "items" | "stats" | "flags">): CatalogSpec {
  return {
    ...(manifest.items === undefined ? {} : { items: manifest.items }),
    ...(manifest.stats === undefined ? {} : { stats: manifest.stats }),
    ...(manifest.flags === undefined ? {} : { flags: manifest.flags }),
  };
}

export type ManifestCheck = { ok: true; manifest: Manifest } | { ok: false; problems: string[] };

const manifestKeys = ["id", "name", "version", "sdk", "license", "mode", "players", "server", "client", "roles", "description", "repository", "options", "items", "stats", "flags"];
export const maxDescriptionLength = 200;

export function validateManifest(raw: unknown, installedSdk: string = sdkVersion): ManifestCheck {
  if (!isRecord(raw)) {
    return { ok: false, problems: ["manifest.json muss ein JSON-Objekt sein"] };
  }
  const problems: string[] = [];
  for (const key of Object.keys(raw)) {
    if (!manifestKeys.includes(key)) {
      problems.push(`${key} ist unbekannt, erlaubt sind ${manifestKeys.join(", ")}`);
    }
  }

  if (typeof raw["id"] !== "string" || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(raw["id"])) {
    problems.push('id muss aus Kleinbuchstaben, Ziffern und Bindestrichen bestehen, z. B. "mau-mau"');
  }
  if (typeof raw["name"] !== "string" || raw["name"].trim() === "") {
    problems.push("name muss ein nicht leerer Text sein");
  }
  if (typeof raw["version"] !== "string" || !/^\d+\.\d+\.\d+(-[0-9A-Za-z.-]+)?$/.test(raw["version"])) {
    problems.push('version muss eine Versionsnummer wie "1.2.0" sein');
  }
  const sdk = raw["sdk"];
  if (typeof sdk !== "string" || !/^\^?\d+\.\d+\.\d+$/.test(sdk)) {
    problems.push(`sdk muss die benötigte SDK-Version angeben, z. B. "^${installedSdk}"`);
  } else if (!satisfies(installedSdk, sdk)) {
    problems.push(`sdk verlangt ${sdk}, vorhanden ist das SDK ${installedSdk}`);
  }
  problems.push(...licenseProblems(raw["license"]));

  const mode = raw["mode"];
  if (!includes(gameModes, mode)) {
    problems.push(`mode muss einer von ${gameModes.join(", ")} sein`);
  }
  for (const problem of validatePlayerCountSpec(raw["players"])) {
    problems.push(problem);
  }
  if (typeof raw["server"] !== "boolean") {
    problems.push("server muss true (Spiel hat einen Reducer) oder false (läuft nur im Browser) sein");
  }
  const clientProblem = clientPathProblem(raw["client"]);
  if (clientProblem !== undefined) {
    problems.push(clientProblem);
  }
  problems.push(...roleProblems(raw["roles"]));
  const description = raw["description"];
  if (description !== undefined && (typeof description !== "string" || description.trim() === "" || description.length > maxDescriptionLength)) {
    problems.push(`description muss ein kurzer Text mit 1 bis ${maxDescriptionLength} Zeichen sein`);
  }
  const repository = raw["repository"];
  if (repository !== undefined && (typeof repository !== "string" || !isHttpsUrl(repository))) {
    problems.push('repository muss die https-Adresse des Quelltexts sein, z. B. "https://github.com/name/spiel"');
  }

  const solo = mode === "single" && raw["server"] === false;
  problems.push(...validateCatalogSpec({ items: raw["items"], stats: raw["stats"], flags: raw["flags"] }, solo));
  if (raw["options"] !== undefined) {
    problems.push(...validateOptionsSpec(raw["options"]));
  }

  if (problems.length === 0) {
    const players = raw["players"] as PlayerCountSpec;
    if (solo && (raw["items"] !== undefined || raw["flags"] !== undefined)) {
      problems.push('items und flags gibt es nur für Spiele mit Reducer; Einzelspieler ohne Reducer (mode "single", server false) halten Inventar und Freischaltungen in ihrem Spielstand und haben unter stats nur Bestwerte');
    }
    const profiles = raw["items"] !== undefined || raw["stats"] !== undefined || raw["flags"] !== undefined;
    if (!solo && profiles && below(String(raw["sdk"]), minimumProfileSdk)) {
      problems.push(`mit items, stats oder flags muss sdk mindestens "^${minimumProfileSdk}" sein, ältere Server kennen keine Profile`);
    }
    if (solo && below(String(raw["sdk"]), minimumSoloSdk)) {
      problems.push(`bei mode "single" ohne Reducer muss sdk mindestens "^${minimumSoloSdk}" sein, ältere Server kennen connectSolo nicht`);
    }
    if (solo && Object.keys(raw["roles"] as Record<string, unknown>).some((role) => role !== "player")) {
      problems.push('bei mode "single" ohne Reducer gibt es nur die Rolle player, keinen Fernseher und keine Controller');
    }
    if (mode === "single" && (players.min !== 1 || players.max !== 1)) {
      problems.push('bei mode "single" muss players { "min": 1, "max": 1 } sein');
    }
    if (mode !== "single" && raw["server"] === false) {
      problems.push(`bei mode "${String(mode)}" muss server true sein, Mehrspieler-Logik läuft auf dem Server`);
    }
    if (raw["options"] !== undefined && raw["server"] === false) {
      problems.push("options gibt es nur für Spiele mit Reducer (server true); Einzelspieler ohne Reducer bauen ihr Menü selbst");
    }
    if (raw["options"] !== undefined && below(String(raw["sdk"]), minimumOptionsSdk)) {
      problems.push(`mit options muss sdk mindestens "^${minimumOptionsSdk}" sein, ältere Server kennen keine Optionen`);
    }
    if (mode === "realtime" && below(String(raw["sdk"]), minimumRealtimeSdk)) {
      problems.push(`bei mode "realtime" muss sdk mindestens "^${minimumRealtimeSdk}" sein, ältere Server kennen tick nicht`);
    }
  }

  return problems.length === 0 ? { ok: true, manifest: raw as unknown as Manifest } : { ok: false, problems };
}

export function licenseProblems(license: unknown): string[] {
  if (!isRecord(license)) {
    return ['license muss ein Objekt wie { "code": "MIT", "assets": "CC0-1.0" } sein'];
  }
  const problems: string[] = [];
  for (const key of Object.keys(license)) {
    if (key !== "code" && key !== "assets") {
      problems.push(`license.${key} ist unbekannt, erlaubt sind code und assets`);
    }
  }
  if (!includes(codeLicenses, license["code"])) {
    problems.push(`license.code muss eine Open-Source-Lizenz sein: ${codeLicenses.join(", ")}`);
  }
  if (!includes(assetLicenses, license["assets"])) {
    problems.push(`license.assets muss eine dieser Lizenzen sein: ${assetLicenses.join(", ")}`);
  }
  return problems;
}

export function roleProblems(roles: unknown): string[] {
  if (!isRecord(roles)) {
    return ['roles muss ein Objekt wie { "player": { "inputs": ["touch"], "screen": "small" } } sein'];
  }
  const problems: string[] = [];
  const names = Object.keys(roles);
  if (!names.includes("player") && !names.includes("controller")) {
    problems.push("roles braucht mindestens player oder controller, sonst kann niemand spielen");
  }
  for (const name of names) {
    if (!includes(roleNames, name)) {
      problems.push(`roles.${name} ist unbekannt, erlaubt sind ${roleNames.join(", ")}`);
      continue;
    }
    const role = roles[name];
    if (!isRecord(role)) {
      problems.push(`roles.${name} muss ein Objekt mit inputs und screen sein`);
      continue;
    }
    for (const key of Object.keys(role)) {
      if (key !== "inputs" && key !== "screen") {
        problems.push(`roles.${name}.${key} ist unbekannt, erlaubt sind inputs und screen`);
      }
    }
    const inputs = role["inputs"];
    if (!Array.isArray(inputs) || !inputs.every((input) => includes(inputKinds, input))) {
      problems.push(`roles.${name}.inputs muss eine Liste aus ${inputKinds.join(", ")} sein`);
    } else if (inputs.length === 0 && name !== "screen") {
      problems.push(`roles.${name}.inputs darf nicht leer sein, nur ein Bildschirm kommt ohne Eingabe aus`);
    }
    if (!includes(screenClasses, role["screen"])) {
      problems.push(`roles.${name}.screen muss einer von ${screenClasses.join(", ")} sein`);
    }
  }
  return problems;
}

export const minimumRealtimeSdk = "0.1.1";
export const minimumSoloSdk = "0.1.2";
export const minimumOptionsSdk = "0.1.3";
export const minimumProfileSdk = "0.1.4";

function below(range: string, version: string): boolean {
  const parse = (text: string) => text.replace(/^\^/, "").split(".").map(Number);
  const [a = 0, b = 0, c = 0] = parse(range);
  const [x = 0, y = 0, z = 0] = parse(version);
  return a !== x ? a < x : b !== y ? b < y : c < z;
}

export function isHttpsUrl(value: string): boolean {
  if (value.length > 300) {
    return false;
  }
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.username === "" && url.password === "" && url.hostname !== "";
  } catch {
    return false;
  }
}

export function satisfies(version: string, range: string): boolean {
  const parse = (text: string) => text.replace(/^\^/, "").split(".").map(Number) as [number, number, number];
  const [major, minor, patch] = parse(version);
  const [wantMajor, wantMinor, wantPatch] = parse(range);
  if (!range.startsWith("^")) {
    return major === wantMajor && minor === wantMinor && patch === wantPatch;
  }
  if (major !== wantMajor) return false;
  if (wantMajor === 0 && minor !== wantMinor) return false;
  if (minor !== wantMinor) return minor > wantMinor;
  return patch >= wantPatch;
}

function includes<T extends string>(list: readonly T[], value: unknown): value is T {
  return typeof value === "string" && (list as readonly string[]).includes(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
