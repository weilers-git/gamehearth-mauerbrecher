import {
  SeededRandom,
  applyMove,
  createMatch,
  randomStateFromSeed,
  refreshMatch,
  seatIds,
  stepMatch,
  tickMs,
  tickRate,
  type AnyGameState,
  type CatalogSpec,
  type GameDefinition,
  type GameOptions,
  type GameResult,
  type Match,
  type MatchError,
  type Move,
  type ProfileChange,
  type ProfileData,
} from "@gamehearth/sdk/platform";
import type { Finding } from "./findings";
import { ProfileSim, removalRandom, stepFingerprintText, type ProfileTrace } from "./profile-sim";

export type AnyGame = GameDefinition<AnyGameState, unknown>;
export type AnyMatch = Match<AnyGameState, unknown>;

export type Ending = "finished" | "too-long" | "failed";

export interface GameRun {
  playerCount: number;
  seed: string;
  options?: GameOptions;
  moves: Move<unknown>[];
  ticks?: number;
  ending: Ending;
  result?: GameResult;
  setupFingerprint?: string;
  setupUsedRandom?: boolean;
  fingerprints?: string[];
  profiles?: ProfileTrace;
  findings: Finding[];
}

export interface RunOptions {
  gameOptions?: GameOptions;
  maxMoves: number;
  maxTicks?: number;
  realtime?: boolean;
  decoyPlayerCount?: number;
  catalog?: CatalogSpec;
  inspect?: (match: AnyMatch, step: number, profiles: Record<string, ProfileData>) => Finding[];
  beforeStep?: (step: number, replaying: boolean) => void;
  onMove?: (move: Move<unknown>) => void;
}

export const clockStart = 1_767_225_600_000;
export const botInputChance = 0.2;
export const realtimeInspectEvery = 10;
export const defaultMaxSeconds = 600;

const snapshotBudget = 20_000_000;

export function playGame(game: AnyGame, playerCount: number, seed: string, options: RunOptions): GameRun {
  const bot = new SeededRandom(randomStateFromSeed(`bot:${seed}`));
  const moves: Move<unknown>[] = [];
  const findings: Finding[] = [];
  const where = runWhere(playerCount, seed, options.gameOptions);

  const sim = ProfileSim.fresh(options.catalog, seatIds(playerCount), seed);
  const traced = withTrace(sim);
  const removals = removalRandom(seed);
  options.beforeStep?.(0, false);
  const created = createMatch(game, { ...matchSetup(playerCount, seed, options.gameOptions), ...sim.input() });
  if (!created.ok) {
    findings.push(fromMatchError(created.error, { ...where, step: 0 }));
    return { ...where, moves, ending: "failed", fingerprints: [], ...traced(), findings };
  }
  let match = created.match;
  const mismatch = modeMismatch(match, options, where);
  if (mismatch !== undefined) {
    return { ...where, moves, ending: "failed", fingerprints: [], ...traced(), findings: [mismatch] };
  }
  if (match.tick !== undefined) {
    return playRealtime(game, match, playerCount, seed, options, sim);
  }
  const history = new History();
  history.add(match);
  const setupFingerprint = fingerprint(JSON.stringify(match.state));
  findings.push(...(options.inspect?.(match, 0, sim.current()) ?? []));

  while (match.result === undefined && moves.length < options.maxMoves) {
    const removal = sim.pickRemoval(removals, moves.length + 1);
    if (removal !== undefined) {
      sim.remove(removal);
      const refreshed = refreshMatch(game, JSON.parse(JSON.stringify(match)) as AnyMatch, sim.input());
      if (!refreshed.ok) {
        findings.push({ ...fromMatchError(refreshed.error, { ...where, step: moves.length }), detail: removalDetail(removal) });
        return { ...where, moves, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
      }
      match = refreshed.match;
    }
    const active = match.players.filter((player) => (match.moves[player] ?? []).length > 0);
    const player = bot.pick(active);
    const move: Move<unknown> = {
      player,
      action: bot.pick(match.moves[player] ?? []),
      now: clockStart + moves.length * 1000,
      expectedVersion: match.version,
    };
    moves.push(move);
    options.onMove?.(move);
    options.beforeStep?.(moves.length, false);
    const before = JSON.stringify(match.state);
    const stored = JSON.parse(JSON.stringify(match)) as AnyMatch;
    const outcome = applyMove(game, stored, JSON.parse(JSON.stringify(move)) as Move<unknown>, sim.input());
    if (!outcome.ok) {
      findings.push(
        outcome.error.code === "missing-item"
          ? missingItem(outcome.error.message, player, move.action, { ...where, step: moves.length })
          : fromMatchError(outcome.error, { ...where, step: moves.length }),
      );
      return { ...where, moves, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
    }
    match = outcome.match;
    const changed = sim.apply(outcome.changes);
    if (changed !== undefined) {
      findings.push({ severity: "error", kind: "game-error", message: `Eine Profiländerung lässt sich nicht nachvollziehen: ${changed}`, ...where, step: moves.length, player });
      return { ...where, moves, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
    }
    if (JSON.stringify(match.state) === before && (outcome.changes ?? []).length === 0) {
      findings.push({
        severity: "warning",
        kind: "suspicious",
        message:
          "Ein erlaubter Zug ändert den Zustand überhaupt nicht. Meist fehlt in apply die Behandlung dieses Zugs, etwa ein case im switch. Soll der Zug wirklich nichts tun, gehört er nicht in legalMoves.",
        detail: `${player} ${JSON.stringify(move.action)}`,
        ...where,
        step: moves.length,
        player,
      });
    }
    history.add(match, outcome.changes);
    findings.push(...(options.inspect?.(match, moves.length, sim.current()) ?? []));
  }

  if (match.result === undefined) {
    findings.push({
      severity: "warning",
      kind: "never-ends",
      message: `Partien enden nach ${options.maxMoves} Zügen mit Zufallsbots noch nicht. Prüfen, ob result das Ende erkennt oder ob sich die Partie im Kreis drehen kann.`,
      ...where,
      step: moves.length,
    });
  }

  const divergence = replayDivergence(game, playerCount, seed, moves, history, options, sim.trace);
  if (divergence !== undefined) {
    findings.push(nondeterministic(where, divergence));
  }

  const base = { ...where, moves, setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
  return match.result === undefined
    ? { ...base, ending: "too-long" }
    : { ...base, ending: "finished", result: match.result };
}

type Where = { playerCount: number; seed: string; options?: GameOptions };

function runWhere(playerCount: number, seed: string, options: GameOptions | undefined): Where {
  return options === undefined || Object.keys(options).length === 0 ? { playerCount, seed } : { playerCount, seed, options };
}

function matchSetup(playerCount: number, seed: string, options: GameOptions | undefined): { playerCount: number; seed: string; options?: GameOptions } {
  return options === undefined ? { playerCount, seed } : { playerCount, seed, options };
}

function withTrace(sim: ProfileSim): () => { profiles?: ProfileTrace } {
  return () => (sim.catalog === undefined || !hasIds(sim.catalog) ? {} : { profiles: sim.trace });
}

function hasIds(catalog: CatalogSpec): boolean {
  return Object.keys(catalog.items ?? {}).length + Object.keys(catalog.stats ?? {}).length + Object.keys(catalog.flags ?? {}).length > 0;
}

function removalDetail(removal: { player: string; item: string; count: number }): string {
  return `Vorher hat check ${removal.player} ${removal.count} × ${removal.item} weggenommen, wie es eine parallele Partie desselben Spielers tun kann; danach rechnet der Server die erlaubten Züge neu.`;
}

function missingItem(message: string, player: string, action: unknown, where: Where & { step: number }): Finding {
  return {
    severity: "error",
    kind: "profile",
    message:
      "legalMoves bietet einen Zug an, für den im Profil ein Item fehlt; apply lehnt ihn bei ctx.profile.use ab, und der Spieler kommt mit diesem Zug nie weiter. legalMoves soll nur Züge anbieten, die das Profil hergibt, etwa nur mit (ctx.profiles[player]?.items.trank ?? 0) > 0.",
    detail: `${player} ${JSON.stringify(action)}: ${message}`,
    ...where,
    player,
  };
}

function modeMismatch(match: AnyMatch, options: RunOptions, where: Where): Finding | undefined {
  if (options.realtime === undefined || options.realtime === (match.tick !== undefined)) {
    return undefined;
  }
  return {
    severity: "error",
    kind: "manifest",
    message: options.realtime
      ? 'Laut manifest.json ist das Spiel mode "realtime", aber es hat keine Funktion tick. Echtzeit-Spiele exportieren defineGame({ setup, legalMoves, apply, tick, result }).'
      : 'Das Spiel hat eine Funktion tick, laut manifest.json ist es aber nicht mode "realtime". Entweder mode auf "realtime" setzen oder tick entfernen.',
    ...where,
    step: 0,
  };
}

function playRealtime(game: AnyGame, created: AnyMatch, playerCount: number, seed: string, options: RunOptions, sim: ProfileSim): GameRun {
  const traced = withTrace(sim);
  const removals = removalRandom(seed);
  let reportedMissing = false;
  const bot = new SeededRandom(randomStateFromSeed(`bot:${seed}`));
  const maxTicks = options.maxTicks ?? defaultMaxSeconds * tickRate;
  const moves: Move<unknown>[] = [];
  const findings: Finding[] = [];
  const where = runWhere(playerCount, seed, options.gameOptions);
  let match = created;
  let ticks = 0;
  const history = new History();
  history.add(match);
  const setupFingerprint = fingerprint(JSON.stringify(match.state));
  findings.push(...tickFindings(options.inspect?.(match, 0, sim.current()) ?? []));

  while (match.result === undefined && ticks < maxTicks) {
    const removal = sim.pickRemoval(removals, ticks + 1);
    if (removal !== undefined) {
      sim.remove(removal);
    }
    const now = clockStart + ticks * tickMs;
    const inputs: { player: string; action: unknown }[] = [];
    for (const player of match.players) {
      const legal = match.moves[player] ?? [];
      if (legal.length > 0 && bot.next() < botInputChance) {
        inputs.push({ player, action: bot.pick(legal) });
      }
    }
    ticks += 1;
    for (const input of inputs) {
      const move: Move<unknown> = { player: input.player, action: input.action, now };
      moves.push(move);
      options.onMove?.(move);
    }
    options.beforeStep?.(ticks, false);
    const stored = JSON.parse(JSON.stringify(match)) as AnyMatch;
    const outcome = stepMatch(game, stored, { inputs: JSON.parse(JSON.stringify(inputs)) as typeof inputs, now, dt: tickMs }, sim.input());
    if (!outcome.ok) {
      findings.push({ ...fromMatchError(outcome.error, { ...where, step: ticks }), unit: "tick" });
      return { ...where, moves, ticks, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
    }
    match = outcome.match;
    if (removal === undefined && !reportedMissing) {
      const missing = outcome.results.findIndex((result, index) => !result.ok && result.code === "missing-item" && outcome.results.slice(0, index).every((before) => !before.ok));
      const input = inputs[missing];
      const result = outcome.results[missing];
      if (input !== undefined && result !== undefined && !result.ok) {
        reportedMissing = true;
        findings.push({ ...missingItem(result.message, input.player, input.action, { ...where, step: ticks }), unit: "tick" });
      }
    }
    const changed = sim.apply(outcome.changes);
    if (changed !== undefined) {
      findings.push({ severity: "error", kind: "game-error", message: `Eine Profiländerung lässt sich nicht nachvollziehen: ${changed}`, ...where, step: ticks, unit: "tick" });
      return { ...where, moves, ticks, ending: "failed", setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
    }
    history.add(match, outcome.changes);
    if (ticks % realtimeInspectEvery === 0 || match.result !== undefined) {
      findings.push(...tickFindings(options.inspect?.(match, ticks, sim.current()) ?? []));
    }
  }

  if (match.result === undefined) {
    findings.push({
      severity: "error",
      kind: "never-ends",
      message: `Partien enden nach ${Math.round(maxTicks / tickRate)} Sekunden Spielzeit (${maxTicks} Ticks) mit Zufallsbots noch nicht. Echtzeit-Spiele brauchen ein Ende, etwa ein Zeitlimit, das tick herunterzählt.`,
      ...where,
      step: ticks,
      unit: "tick",
    });
  }

  const divergence = replayRealtimeDivergence(game, playerCount, seed, moves, ticks, history, options, sim.trace);
  if (divergence !== undefined) {
    findings.push({ ...nondeterministic(where, divergence), unit: "tick" });
  }

  const base = { ...where, moves, ticks, setupFingerprint, fingerprints: history.fingerprints, ...traced(), findings };
  return match.result === undefined ? { ...base, ending: "too-long" } : { ...base, ending: "finished", result: match.result };
}

function tickFindings(findings: Finding[]): Finding[] {
  return findings.map((finding) => (finding.step === undefined ? finding : { ...finding, unit: "tick" }));
}

export function stepInputs(moves: readonly Move<unknown>[], tick: number): { player: string; action: unknown }[] {
  const now = clockStart + (tick - 1) * tickMs;
  return moves.filter((move) => move.now === now).map((move) => ({ player: move.player, action: move.action }));
}

function replayRealtimeDivergence(
  game: AnyGame,
  playerCount: number,
  seed: string,
  moves: readonly Move<unknown>[],
  ticks: number,
  history: History,
  options: RunOptions,
  trace: ProfileTrace,
): Divergence | undefined {
  const decoy = new Decoy(game, options.decoyPlayerCount ?? playerCount, seed, options.gameOptions, options.catalog);
  const sim = new ProfileSim(options.catalog, seatIds(playerCount), trace);
  const diverged = (step: number, actual: AnyMatch | undefined, changes?: readonly ProfileChange[]): Divergence => {
    const detail = history.describe(step, actual, changes);
    return detail === undefined ? { step } : { step, detail };
  };
  options.beforeStep?.(0, true);
  const created = createMatch(game, { ...matchSetup(playerCount, seed, options.gameOptions), ...sim.input() });
  if (!created.ok) {
    return { step: 0, detail: `beim Wiederholen meldet setup: ${created.error.message}` };
  }
  let match = created.match;
  if (!history.matches(0, match)) {
    return diverged(0, match);
  }
  decoy.advance();
  for (let tick = 1; tick <= ticks; tick++) {
    decoy.advance();
    options.beforeStep?.(tick, true);
    for (const removal of sim.removalsAt(tick)) {
      sim.remove(removal);
    }
    const outcome = stepMatch(game, match, { inputs: stepInputs(moves, tick), now: clockStart + (tick - 1) * tickMs, dt: tickMs }, sim.input());
    if (!outcome.ok) {
      return { step: tick, detail: `beim Wiederholen scheitert der Tick: ${outcome.error.message}` };
    }
    if (!history.matches(tick, outcome.match, outcome.changes)) {
      return diverged(tick, outcome.match, outcome.changes);
    }
    sim.apply(outcome.changes);
    match = outcome.match;
  }
  return undefined;
}

function nondeterministic(where: Where, divergence: Divergence): Finding {
  const finding: Finding = {
    severity: "error",
    kind: "nondeterministic",
    message:
      "Dieselbe Partie ergibt beim Wiederholen einen anderen Zustand. Das Spiel hängt von etwas anderem ab als von Zustand, Zug und ctx: etwa von Variablen außerhalb der Funktionen, die sich setup merkt oder die sich zwischen Partien ändern. Auf dem Server laufen viele Partien gleichzeitig im selben Modul.",
    ...where,
    step: divergence.step,
  };
  if (divergence.detail !== undefined) {
    finding.detail = divergence.detail;
  }
  return finding;
}

class History {
  readonly #fingerprints: string[] = [];
  readonly #snapshots: (string | undefined)[] = [];
  #size = 0;

  get fingerprints(): string[] {
    return [...this.#fingerprints];
  }

  add(match: AnyMatch, changes?: readonly ProfileChange[]): void {
    const text = stepFingerprintText(match, changes);
    this.#fingerprints.push(fingerprint(text));
    if (this.#size + text.length <= snapshotBudget) {
      this.#snapshots.push(text);
      this.#size += text.length;
    } else {
      this.#snapshots.push(undefined);
    }
  }

  matches(step: number, match: AnyMatch, changes?: readonly ProfileChange[]): boolean {
    return this.#fingerprints[step] === fingerprint(stepFingerprintText(match, changes));
  }

  describe(step: number, actual: AnyMatch | undefined, changes?: readonly ProfileChange[]): string | undefined {
    const expected = this.#snapshots[step];
    if (expected === undefined || actual === undefined) {
      return undefined;
    }
    return firstDifference(JSON.parse(expected), JSON.parse(stepFingerprintText(actual, changes)), "match");
  }
}

interface Divergence {
  step: number;
  detail?: string;
}

function replayDivergence(
  game: AnyGame,
  playerCount: number,
  seed: string,
  moves: readonly Move<unknown>[],
  history: History,
  options: RunOptions,
  trace: ProfileTrace,
): Divergence | undefined {
  const decoy = new Decoy(game, options.decoyPlayerCount ?? playerCount, seed, options.gameOptions, options.catalog);
  const sim = new ProfileSim(options.catalog, seatIds(playerCount), trace);
  const diverged = (step: number, actual: AnyMatch | undefined, changes?: readonly ProfileChange[]): Divergence => {
    const detail = history.describe(step, actual, changes);
    return detail === undefined ? { step } : { step, detail };
  };
  options.beforeStep?.(0, true);
  const created = createMatch(game, { ...matchSetup(playerCount, seed, options.gameOptions), ...sim.input() });
  if (!created.ok) {
    return { step: 0, detail: `beim Wiederholen meldet setup: ${created.error.message}` };
  }
  let match = created.match;
  if (!history.matches(0, match)) {
    return diverged(0, match);
  }
  decoy.advance();
  for (let step = 1; step <= moves.length; step++) {
    decoy.advance();
    options.beforeStep?.(step, true);
    const removals = sim.removalsAt(step);
    if (removals.length > 0) {
      for (const removal of removals) {
        sim.remove(removal);
      }
      const refreshed = refreshMatch(game, match, sim.input());
      if (!refreshed.ok) {
        return { step, detail: `beim Wiederholen scheitert das Neuberechnen der Züge: ${refreshed.error.message}` };
      }
      match = refreshed.match;
    }
    const outcome = applyMove(game, match, moves[step - 1] as Move<unknown>, sim.input());
    if (!outcome.ok) {
      return { step, detail: `beim Wiederholen wird der Zug abgelehnt: ${outcome.error.message}` };
    }
    if (!history.matches(step, outcome.match, outcome.changes)) {
      return diverged(step, outcome.match, outcome.changes);
    }
    sim.apply(outcome.changes);
    match = outcome.match;
  }
  return undefined;
}

class Decoy {
  readonly #game: AnyGame;
  readonly #playerCount: number;
  readonly #seed: string;
  readonly #bot: SeededRandom;
  readonly #options: GameOptions | undefined;
  readonly #catalog: { catalog?: CatalogSpec };
  #match: AnyMatch | undefined;
  #round = 0;

  constructor(game: AnyGame, playerCount: number, seed: string, options: GameOptions | undefined, catalog: CatalogSpec | undefined) {
    this.#game = game;
    this.#playerCount = playerCount;
    this.#seed = seed;
    this.#options = options;
    this.#catalog = catalog === undefined ? {} : { catalog };
    this.#bot = new SeededRandom(randomStateFromSeed(`decoy:${seed}`));
  }

  advance(): void {
    try {
      if (this.#match === undefined || this.#match.result !== undefined) {
        this.#round += 1;
        const created = createMatch(this.#game, { ...matchSetup(this.#playerCount, `decoy:${this.#seed}:${this.#round}`, this.#options), ...this.#catalog });
        this.#match = created.ok ? created.match : undefined;
        return;
      }
      const match = this.#match;
      if (match.tick !== undefined) {
        const inputs = match.players
          .filter((player) => (match.moves[player] ?? []).length > 0 && this.#bot.next() < botInputChance)
          .map((player) => ({ player, action: this.#bot.pick(match.moves[player] ?? []) }));
        const stepped = stepMatch(this.#game, match, { inputs, now: clockStart, dt: tickMs }, this.#catalog);
        this.#match = stepped.ok ? stepped.match : undefined;
        return;
      }
      const active = match.players.filter((player) => (match.moves[player] ?? []).length > 0);
      const player = this.#bot.pick(active);
      const outcome = applyMove(
        this.#game,
        match,
        {
          player,
          action: this.#bot.pick(match.moves[player] ?? []),
          now: clockStart,
        },
        this.#catalog,
      );
      this.#match = outcome.ok ? outcome.match : undefined;
    } catch {
      this.#match = undefined;
    }
  }
}

export function firstDifference(expected: unknown, actual: unknown, path: string): string | undefined {
  if (JSON.stringify(expected) === JSON.stringify(actual)) {
    return undefined;
  }
  const isObject = (value: unknown) => value !== null && typeof value === "object";
  if (isObject(expected) && isObject(actual) && Array.isArray(expected) === Array.isArray(actual)) {
    const a = expected as Record<string, unknown>;
    const b = actual as Record<string, unknown>;
    const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])];
    for (const key of keys) {
      const childPath = Array.isArray(expected) ? `${path}[${key}]` : `${path}.${key}`;
      const difference = firstDifference(a[key], b[key], childPath);
      if (difference !== undefined) {
        return difference;
      }
    }
  }
  return `${path}: beim ersten Durchlauf ${short(expected)}, beim Wiederholen ${short(actual)}`;
}

function short(value: unknown): string {
  const text = value === undefined ? "nicht vorhanden" : JSON.stringify(value);
  return text.length > 120 ? `${text.slice(0, 117)}...` : text;
}

export function fromMatchError(error: MatchError, where: Where & { step: number }): Finding {
  const finding: Finding = {
    severity: "error",
    kind: "game-error",
    message: error.code === "game-error" ? error.message : `Unerwartete Ablehnung (${error.code}): ${error.message}`,
    ...where,
  };
  if (error.phase !== undefined) {
    finding.phase = error.phase;
  }
  if (error.player !== undefined) {
    finding.player = error.player;
  }
  if (error.stack !== undefined) {
    finding.stack = gameFrames(error.stack);
  }
  return finding;
}

const platformFrame = /[\\/](sdk|devtool)[\\/]src[\\/]|[\\/]@gamehearth[\\/](sdk|devtool)[\\/]|[\\/]node_modules[\\/]gamehearth[\\/]|gamehearth-check-/;

export function gameFrames(stack: string): string {
  const lines = stack.split("\n");
  const kept = lines.filter((line, index) => index === 0 || !line.trim().startsWith("at ") || !platformFrame.test(line));
  return kept.length > 1 ? kept.join("\n") : stack;
}

export function fingerprint(text: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return `${text.length}:${(hash >>> 0).toString(16)}`;
}
