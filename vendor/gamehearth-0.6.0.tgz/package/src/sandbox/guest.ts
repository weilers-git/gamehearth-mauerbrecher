import "./prelude";
import { applyMove, createMatch, refreshMatch, stepMatch, type AnyGameState, type CatalogSpec, type GameDefinition, type GameOptions } from "@gamehearth/sdk/platform";

type AnyGame = GameDefinition<AnyGameState, unknown>;

let installed: AnyGame | undefined;
let catalog: CatalogSpec | undefined;

function game(): AnyGame {
  if (installed === undefined) {
    throw new Error("kein Spiel installiert");
  }
  return installed;
}

function profileInput(profiles: unknown): { catalog?: CatalogSpec; profiles?: Record<string, unknown> } {
  return {
    ...(catalog === undefined ? {} : { catalog }),
    ...(profiles === undefined || profiles === null ? {} : { profiles: profiles as Record<string, unknown> }),
  };
}

const api = {
  install(value: unknown, catalogJson?: unknown): void {
    const candidate = value as Record<string, unknown> | null;
    const complete =
      candidate !== null &&
      typeof candidate === "object" &&
      ["setup", "legalMoves", "apply", "result"].every((name) => typeof candidate[name] === "function");
    if (!complete) {
      throw new Error(
        "src/index.ts exportiert kein Spiel. Das Spiel muss so exportiert werden: export default defineGame({ setup, legalMoves, apply, result })",
      );
    }
    installed = candidate as unknown as AnyGame;
    catalog = typeof catalogJson === "string" ? (JSON.parse(catalogJson) as CatalogSpec) : undefined;
  },
  createMatch(input: string): string {
    const { playerCount, seed, options, profiles } = JSON.parse(input) as { playerCount: number; seed: string; options?: GameOptions; profiles?: unknown };
    return JSON.stringify(createMatch(game(), { playerCount, seed, ...(options === undefined ? {} : { options }), ...profileInput(profiles) }));
  },
  applyMove(input: string): string {
    const { match, move, profiles } = JSON.parse(input);
    return JSON.stringify(applyMove(game(), match, move, profileInput(profiles)));
  },
  stepMatch(input: string): string {
    const { match, step, profiles } = JSON.parse(input);
    return JSON.stringify(stepMatch(game(), match, step, profileInput(profiles)));
  },
  refreshMatch(input: string): string {
    const { match, profiles } = JSON.parse(input);
    return JSON.stringify(refreshMatch(game(), match, profileInput(profiles)));
  },
};

Object.defineProperty(globalThis, "__gamehearth", { value: Object.freeze(api), writable: false, enumerable: false, configurable: false });
