const globals = globalThis as Record<string, unknown>;

const randomReason = "Zufall kommt aus ctx.random, die Zeit aus ctx.now; nur so lässt sich jede Partie exakt wiederholen.";
const zoneReason = "Das Ergebnis hängt von der Zeitzone des Rechners ab; stattdessen die UTC-Methoden wie getUTCHours() und Date.UTC(...) verwenden.";
const codeReason = "Spiele bauen keinen Code aus Text.";

const localDateMethods = [
  "getFullYear",
  "getYear",
  "getMonth",
  "getDate",
  "getDay",
  "getHours",
  "getMinutes",
  "getSeconds",
  "getTimezoneOffset",
  "setFullYear",
  "setYear",
  "setMonth",
  "setDate",
  "setHours",
  "setMinutes",
  "setSeconds",
  "toString",
  "toDateString",
  "toTimeString",
  "toLocaleString",
  "toLocaleDateString",
  "toLocaleTimeString",
];

function forbidden(call: string, reason: string): () => never {
  return () => {
    throw new Error(`${call} ist in Spielen nicht erlaubt. ${reason}`);
  };
}

function lock(target: object, key: string, value: unknown): void {
  Object.defineProperty(target, key, { value, writable: false, enumerable: false, configurable: false });
}

lock(Math, "random", forbidden("Math.random()", randomReason));

const RealDate = Date;
lock(RealDate, "now", forbidden("Date.now()", randomReason));
lock(RealDate, "parse", forbidden("Date.parse()", zoneReason));
for (const name of localDateMethods) {
  lock(RealDate.prototype, name, forbidden(`Date.prototype.${name}()`, zoneReason));
}
const SafeDate = new Proxy(RealDate, {
  apply: forbidden("Date()", randomReason),
  construct(target, args, newTarget) {
    if (args.length === 0) {
      forbidden("new Date() ohne Argument", randomReason)();
    }
    if (args.length > 1 || typeof args[0] !== "number") {
      forbidden("new Date(...) mit Text oder mehreren Argumenten", zoneReason)();
    }
    return Reflect.construct(target, args, newTarget) as object;
  },
});
lock(globals, "Date", SafeDate);
lock(RealDate.prototype, "constructor", SafeDate);

function safeConstructor(prototype: object): () => never {
  const safe = function () {
    forbidden("Der Function-Konstruktor", codeReason)();
  } as unknown as () => never;
  Object.defineProperty(safe, "prototype", { value: prototype, writable: false, enumerable: false, configurable: false });
  return safe;
}

for (const sample of [function () {}, function* () {}, async function () {}, async function* () {}]) {
  const prototype = Object.getPrototypeOf(sample) as object;
  const safe = safeConstructor(prototype);
  lock(prototype, "constructor", safe);
  if (prototype === Function.prototype) {
    lock(globals, "Function", safe);
  }
}
lock(globals, "eval", forbidden("eval()", codeReason));

for (const name of ["WeakRef", "FinalizationRegistry", "performance"]) {
  delete globals[name];
}
