import { cloneProfile, emptyProfile, profileProblem, readProfile, type ProfileData } from "@gamehearth/sdk/platform";
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

export const devProfilesFile = join(".gamehearth", "dev-profiles.json");

export type ProfilesResult = { ok: true } | { ok: false; code: string; message: string };

interface Stored {
  seats: Record<string, ProfileData>;
  guests: string[];
  broken: boolean;
}

const seatPattern = /^p\d{1,2}$/;
const untilRepaired = "dev schreibt nichts hinein, bis sie repariert ist; danach eine neue Partie starten.";

export class DevProfiles {
  readonly #file: string;
  #problem: string | undefined;

  constructor(gameDir: string) {
    this.#file = join(gameDir, devProfilesFile);
  }

  get path(): string {
    return this.#file;
  }

  get problem(): string | undefined {
    this.#read();
    return this.#problem;
  }

  profile(seat: string): ProfileData {
    const stored = this.#read();
    const profile = Object.hasOwn(stored.seats, seat) ? stored.seats[seat] : undefined;
    return profile === undefined ? emptyProfile() : cloneProfile(profile);
  }

  guests(): string[] {
    return [...this.#read().guests];
  }

  isGuest(seat: string): boolean {
    return this.#read().guests.includes(seat);
  }

  save(profiles: Readonly<Record<string, ProfileData>>, guests: readonly string[]): ProfilesResult {
    const stored = this.#read();
    const seats = { ...stored.seats };
    for (const [seat, profile] of Object.entries(profiles)) {
      if (!guests.includes(seat)) {
        seats[seat] = cloneProfile(profile);
      }
    }
    return this.#write(stored, { seats, guests: stored.guests });
  }

  setGuest(seat: string, guest: boolean): ProfilesResult {
    const stored = this.#read();
    const guests = guest ? [...new Set([...stored.guests, seat])].sort() : stored.guests.filter((entry) => entry !== seat);
    return this.#write(stored, { seats: stored.seats, guests });
  }

  #read(): Stored {
    if (!existsSync(this.#file)) {
      this.#problem = undefined;
      return { seats: {}, guests: [], broken: false };
    }
    let raw: unknown;
    try {
      raw = JSON.parse(readFileSync(this.#file, "utf8").replace(/^﻿/, ""));
    } catch (error) {
      this.#problem = `${devProfilesFile} ist kein gültiges JSON (${error instanceof Error ? error.message : String(error)}). Alle Sitze spielen mit leeren Profilen, und ${untilRepaired}`;
      return { seats: {}, guests: [], broken: true };
    }
    const problems: string[] = [];
    const seats: Record<string, ProfileData> = {};
    let guests: string[] = [];
    if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
      problems.push(`Die Datei muss ein Objekt der Form { "seats": { "p1": { … } }, "guests": [] } sein, ist aber ${Array.isArray(raw) ? "eine Liste" : JSON.stringify(raw)}.`);
    } else {
      const record = raw as Record<string, unknown>;
      for (const key of Object.keys(record).filter((entry) => entry !== "seats" && entry !== "guests")) {
        problems.push(`Den Schlüssel ${JSON.stringify(key.slice(0, 40))} gibt es nicht; erlaubt sind "seats" und "guests".`);
      }
      const rawSeats = record["seats"];
      if (rawSeats !== undefined && (rawSeats === null || typeof rawSeats !== "object" || Array.isArray(rawSeats))) {
        problems.push(`"seats" muss ein Objekt mit einem Profil je Sitz sein, etwa { "p1": { "items": { … } } }.`);
      } else if (rawSeats !== undefined) {
        for (const [seat, profile] of Object.entries(rawSeats as Record<string, unknown>)) {
          const problem = seatPattern.test(seat) ? profileProblem(profile) : "Sitze heißen p1, p2 und so weiter";
          if (problem === undefined) {
            seats[seat] = readProfile(profile);
          } else {
            problems.push(`seats.${seat.slice(0, 20)}: ${problem}. Der Sitz beginnt mit einem leeren Profil.`);
          }
        }
      }
      const rawGuests = record["guests"];
      if (rawGuests !== undefined && !(Array.isArray(rawGuests) && rawGuests.every((seat) => typeof seat === "string" && seatPattern.test(seat)))) {
        problems.push(`"guests" muss eine Liste von Sitzen sein, etwa ["p2"].`);
      } else if (Array.isArray(rawGuests)) {
        guests = [...(rawGuests as string[])];
      }
    }
    this.#problem = problems.length === 0 ? undefined : `${devProfilesFile}: ${problems.join(" ")} ${untilRepaired}`;
    return { seats, guests, broken: problems.length > 0 };
  }

  #write(current: Stored, next: Omit<Stored, "broken">): ProfilesResult {
    if (current.broken) {
      return { ok: false, code: "broken-profiles-file", message: this.#problem ?? `${devProfilesFile} ist kaputt.` };
    }
    try {
      mkdirSync(dirname(this.#file), { recursive: true });
      const temporary = `${this.#file}.tmp`;
      const seats = Object.fromEntries(Object.keys(next.seats).sort().map((seat) => [seat, next.seats[seat]]));
      writeFileSync(temporary, `${JSON.stringify({ seats, guests: next.guests }, null, 2)}\n`);
      renameSync(temporary, this.#file);
      return { ok: true };
    } catch (error) {
      return { ok: false, code: "platform-error", message: `${devProfilesFile} lässt sich nicht schreiben: ${error instanceof Error ? error.message : String(error)}` };
    }
  }
}
