import { seatIds, tickMs, type AnyGameState, type CatalogSpec, type GameOptions, type Match } from "@gamehearth/sdk/platform";
import type { Finding } from "./findings";
import { ProfileSim, stepFingerprintText } from "./profile-sim";
import { clockStart, fingerprint, stepInputs, type GameRun } from "./runner";
import { buildGuestRunner } from "./sandbox/build";
import { Sandbox, sandboxDefaults, workerStackSizeBytes, type SandboxResult } from "./sandbox/sandbox";

const serverHint = `Dort fehlen unter anderem console, structuredClone, Intl, TextEncoder, atob und URL; eval, der Function-Konstruktor und Datumsmethoden mit Ortszeit sind gesperrt, und ein Aufruf darf höchstens ${sandboxDefaults.callTimeoutMs} ms dauern.`;

const divergence =
  "Auf dem Server (QuickJS) ergibt dieselbe Partie einen anderen Zustand als hier in Node. Häufige Ursachen: Math.sin, Math.cos, Math.exp, Math.pow, Math.hypot und Verwandte rechnen in den letzten Stellen anders; localeCompare und toLocaleString kennen dort kein Gebietsschema; ein Vergleicher für sort liefert nicht konsistent negativ, 0 oder positiv. Auf dem Server bleibt jede Partie in sich wiederholbar, aber check hat dort nicht genau diese Partien geprüft.";

export const slowTickAverageMs = 10;
export const slowTickMaxMs = 40;

export async function replayInQuickJs(code: string, runs: readonly GameRun[], catalog?: CatalogSpec): Promise<Finding[]> {
  const catalogJson = catalog === undefined ? undefined : JSON.stringify(catalog);
  const runner = await buildGuestRunner();
  const findings: Finding[] = [];
  const timings: number[] = [];
  for (const run of runs) {
    const fingerprints = run.fingerprints ?? [];
    if (fingerprints.length === 0) {
      continue;
    }
    const where = { playerCount: run.playerCount, seed: run.seed, ...(run.options === undefined ? {} : { options: run.options }) };
    let sandbox: Sandbox;
    const fresh = () => Sandbox.create(runner, code, { maxStackSizeBytes: workerStackSizeBytes }, catalogJson);
    try {
      sandbox = await fresh();
    } catch (error) {
      findings.push({
        severity: "error",
        kind: "engine",
        message: `Auf dem Server (QuickJS) lässt sich das Spiel nicht laden: ${error instanceof Error ? error.message : String(error)}. ${serverHint}`,
      });
      return findings;
    }
    try {
      const finding = await replayOne(
        () => sandbox,
        async () => {
          sandbox.dispose();
          sandbox = await fresh();
          return sandbox;
        },
        run,
        fingerprints,
        where,
        timings,
        catalog,
      );
      if (finding !== undefined) {
        findings.push(finding);
        if (finding.severity === "error") {
          return findings;
        }
      }
    } finally {
      sandbox.dispose();
    }
  }
  const slow = slowTicks(timings, runs[0]?.playerCount);
  if (slow !== undefined) {
    findings.push(slow);
  }
  return findings;
}

function slowTicks(timings: readonly number[], playerCount: number | undefined): Finding | undefined {
  if (timings.length === 0) {
    return undefined;
  }
  const average = timings.reduce((sum, value) => sum + value, 0) / timings.length;
  const sorted = [...timings].sort((a, b) => a - b);
  const high = sorted[Math.floor(sorted.length * 0.99)] ?? 0;
  if (average <= slowTickAverageMs && high <= slowTickMaxMs) {
    return undefined;
  }
  const finding: Finding = {
    severity: "warning",
    kind: "engine",
    message: `Ein Tick braucht auf dem Server (QuickJS) lange. Bei 20 Ticks pro Sekunde bleiben 50 ms für alle Räume des Servers; über ${slowTickAverageMs} ms im Schnitt oder ${slowTickMaxMs} ms in Spitzen ruckelt es, sobald mehrere Räume laufen. Den Zustand klein halten (wenige Objekte, Raster als Text oder Zahlenliste) und in tick und legalMoves nichts unnötig neu berechnen.`,
    detail: `im Schnitt ${average.toFixed(1)} ms, in Spitzen ${high.toFixed(1)} ms pro Tick samt Eingaben`,
  };
  if (playerCount !== undefined) {
    finding.playerCount = playerCount;
  }
  return finding;
}

async function replayOne(
  current: () => Sandbox,
  renew: () => Promise<Sandbox>,
  run: GameRun,
  fingerprints: readonly string[],
  where: { playerCount: number; seed: string; options?: GameOptions },
  timings: number[],
  catalog: CatalogSpec | undefined,
): Promise<Finding | undefined> {
  const players = seatIds(run.playerCount);
  const realtime = run.ticks !== undefined;
  const options = run.options === undefined ? {} : { options: run.options };
  const sim = new ProfileSim(catalog, players, run.profiles ?? { start: {}, removals: [] });
  const profiles = () => sim.input().profiles;
  let result = current().run("createMatch", JSON.stringify({ playerCount: run.playerCount, seed: run.seed, ...options, profiles: profiles() }), {
    seed: run.seed,
    players,
    ...options,
    version: 0,
    ...(realtime ? { tick: 0 } : {}),
  });
  for (let step = 0; step < fingerprints.length; step++) {
    if (step > 0 && realtime) {
      const match = matchOf(result) as Match<AnyGameState, unknown>;
      for (const removal of sim.removalsAt(step)) {
        sim.remove(removal);
      }
      const inputs = stepInputs(run.moves, step);
      const input = JSON.stringify({ match, step: { inputs, now: clockStart + (step - 1) * tickMs, dt: tickMs }, profiles: profiles() });
      const expected = { seed: run.seed, players, ...options, version: match.version + 1, tick: (match.tick ?? 0) + 1, inputs: inputs.length };
      const started = performance.now();
      result = current().run("stepMatch", input, expected);
      if (!result.ok && result.failure.kind === "timeout") {
        const retried = await renew();
        const again = performance.now();
        result = retried.run("stepMatch", input, expected);
        timings.push(performance.now() - again);
      } else {
        timings.push(performance.now() - started);
      }
    } else if (step > 0) {
      let match = matchOf(result) as Match<AnyGameState, unknown>;
      const removals = sim.removalsAt(step);
      if (removals.length > 0) {
        for (const removal of removals) {
          sim.remove(removal);
        }
        const refreshed = current().run("refreshMatch", JSON.stringify({ match, profiles: profiles() }), { seed: run.seed, players, ...options, version: match.version + 1 });
        const problem = failureOf(refreshed);
        if (problem !== undefined) {
          return { severity: "error", kind: "engine", message: `Auf dem Server (QuickJS) scheitert das Neuberechnen der Züge, hier in Node nicht: ${problem}. ${serverHint}`, ...where, step };
        }
        match = matchOf(refreshed) as Match<AnyGameState, unknown>;
      }
      const move = run.moves[step - 1];
      result = current().run("applyMove", JSON.stringify({ match, move, profiles: profiles() }), { seed: run.seed, players, ...options, version: match.version + 1 });
    }
    const failed = failureOf(result);
    if (failed !== undefined) {
      return {
        severity: "error",
        kind: "engine",
        message: `Auf dem Server (QuickJS) scheitert die Partie, hier in Node nicht: ${failed}. ${serverHint}`,
        ...where,
        step,
        ...(realtime ? { unit: "tick" as const } : {}),
      };
    }
    const changes = result.ok && result.outcome.ok ? result.outcome.changes : undefined;
    if (fingerprint(stepFingerprintText(matchOf(result), changes)) !== fingerprints[step]) {
      return { severity: "warning", kind: "engine", message: divergence, ...where, step, ...(realtime ? { unit: "tick" as const } : {}) };
    }
    sim.apply(changes);
  }
  return undefined;
}

function matchOf(result: SandboxResult): unknown {
  return result.ok && result.outcome.ok ? result.outcome.match : undefined;
}

function failureOf(result: SandboxResult): string | undefined {
  if (!result.ok) {
    return result.failure.message;
  }
  return result.outcome.ok ? undefined : result.outcome.error.message;
}
