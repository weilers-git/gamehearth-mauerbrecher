import { catalogIds, catalogSections, profileIdPattern, type CatalogSection } from "@gamehearth/sdk/platform";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import type { Finding } from "./findings";
import { catalogOf, type Manifest } from "./manifest";

export type IdsLockMode = "write" | "verify";

export const idsLockFile = "ids.lock";

export const idsLockNote =
  "Von gamehearth check gepflegt. Jede ID, die hier steht, bleibt für immer im Spiel (in manifest.json, notfalls mit \"deprecated\": true). Von Hand entfernen darf man nur IDs, die nie veröffentlicht wurden.";

export interface IdsLock {
  format: 1;
  items: string[];
  stats: string[];
  flags: string[];
}

export interface IdsLockReport {
  findings: Finding[];
  notes: string[];
  written: boolean;
}

export function idsLockMode(env: Readonly<Record<string, string | undefined>> = process.env): IdsLockMode {
  const ci = env["CI"];
  return ci !== undefined && ci !== "" && ci !== "false" && ci !== "0" ? "verify" : "write";
}

export function formatIdsLock(lock: IdsLock): string {
  return `${JSON.stringify({ format: 1, hinweis: idsLockNote, items: lock.items, stats: lock.stats, flags: lock.flags }, null, 2)}\n`;
}

export function parseIdsLock(text: string): IdsLock | string {
  let raw: unknown;
  try {
    raw = JSON.parse(text.replace(/^﻿/, ""));
  } catch {
    return `${idsLockFile} ist kein gültiges JSON`;
  }
  if (raw === null || typeof raw !== "object" || Array.isArray(raw) || (raw as Record<string, unknown>)["format"] !== 1) {
    return `${idsLockFile} hat nicht die Form { "format": 1, "items": [...], "stats": [...], "flags": [...] }`;
  }
  const record = raw as Record<string, unknown>;
  const lock: IdsLock = { format: 1, items: [], stats: [], flags: [] };
  for (const section of catalogSections) {
    const list = record[section] ?? [];
    if (!Array.isArray(list) || !list.every((id) => typeof id === "string" && profileIdPattern.test(id))) {
      return `${idsLockFile}: ${section} muss eine Liste von IDs wie "trank-heilung" sein`;
    }
    lock[section] = [...new Set(list as string[])].sort();
  }
  return lock;
}

export async function checkIdsLock(dir: string, manifest: Manifest, mode: IdsLockMode): Promise<IdsLockReport> {
  const report: IdsLockReport = { findings: [], notes: [], written: false };
  const current = catalogIds(catalogOf(manifest));
  const file = join(dir, idsLockFile);
  let text: string | undefined;
  try {
    text = await readFile(file, "utf8");
  } catch {
    text = undefined;
  }
  const empty = catalogSections.every((section) => current[section].length === 0);
  if (text === undefined && empty) {
    return report;
  }
  const parsed = text === undefined ? { format: 1 as const, items: [], stats: [], flags: [] } : parseIdsLock(text);
  if (typeof parsed === "string") {
    report.findings.push({
      severity: "error",
      kind: "ids",
      message: `${parsed}. Die Datei führt alle IDs, die das Spiel je hatte; sie aus dem Verlauf (git) wiederherstellen, statt sie neu anzulegen.`,
    });
    return report;
  }
  for (const section of catalogSections) {
    const missing = parsed[section].filter((id) => !current[section].includes(id));
    if (missing.length > 0) {
      report.findings.push({
        severity: "error",
        kind: "ids",
        message: `manifest.json: ${describeIds(section, missing)} in ${idsLockFile}, ${missing.length === 1 ? "fehlt" : "fehlen"} aber unter ${section}. Profile überleben Spielversionen; eine einmal veröffentlichte ID darf nie verschwinden. Wieder eintragen und mit "deprecated": true markieren. Nur eine ID, die nie veröffentlicht wurde, darf man von Hand aus ${idsLockFile} löschen.`,
      });
    }
  }
  const added = Object.fromEntries(catalogSections.map((section) => [section, current[section].filter((id) => !parsed[section].includes(id))])) as Record<
    CatalogSection,
    string[]
  >;
  const newIds = catalogSections.filter((section) => added[section].length > 0);
  if (newIds.length === 0 && text !== undefined) {
    return report;
  }
  const listed = newIds.map((section) => `${section}: ${added[section].join(", ")}`).join("; ");
  if (mode === "verify") {
    report.findings.push({
      severity: "error",
      kind: "ids",
      message:
        text === undefined
          ? `${idsLockFile} fehlt, obwohl manifest.json IDs hat (${listed}). Lokal npm run check laufen lassen und ${idsLockFile} committen; in der CI (CI gesetzt) schreibt check die Datei nicht selbst.`
          : `${idsLockFile} ist veraltet, es fehlen ${listed}. Lokal npm run check laufen lassen und ${idsLockFile} committen; in der CI (CI gesetzt) schreibt check die Datei nicht selbst.`,
    });
    return report;
  }
  const next: IdsLock = { format: 1, items: [], stats: [], flags: [] };
  for (const section of catalogSections) {
    next[section] = [...new Set([...parsed[section], ...current[section]])].sort();
  }
  await writeFile(file, formatIdsLock(next));
  report.written = true;
  report.notes.push(
    text === undefined
      ? `${idsLockFile} angelegt mit ${listed}. Die Datei gehört ins Repo; sie hält fest, welche IDs es je gab.`
      : `${idsLockFile}: neu eingetragen ${listed}. Die Änderung gehört ins Repo.`,
  );
  return report;
}

function describeIds(section: CatalogSection, ids: readonly string[]): string {
  const names = ids.map((id) => `"${id}"`).join(", ");
  const one = section === "items" ? "Das Item" : section === "stats" ? "Der Stat" : "Das Flag";
  const many = section === "items" ? "Die Items" : section === "stats" ? "Die Stats" : "Die Flags";
  return ids.length === 1 ? `${one} ${names} steht` : `${many} ${names} stehen`;
}
