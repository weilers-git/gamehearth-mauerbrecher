import { describe, expect, it } from "vitest";
import { blendPositions, clock, controllerLine, fitField, needsResend, padDirection, pressKey, ranking, releaseKey, resultLine, seatColor, steer, topKey, type Snapshot } from "../client/src/view";
import type { Public } from "../src/index";

const players = { p1: { name: "Anna", connected: true, you: true }, p2: { name: "Ben", connected: true, you: false } };

function view(changes: Partial<Public> = {}): Public {
  return {
    pos: { p1: { x: 10, y: 10 }, p2: { x: 100, y: 50 } },
    dir: { p1: "none", p2: "none" },
    catcher: "p2",
    frozen: 0,
    tagBack: null,
    tagBackLeft: 0,
    caught: { p1: 40, p2: 30 },
    ticksLeft: 1200,
    ...changes,
  };
}

function snapshot(changes: Partial<Snapshot> = {}): Snapshot {
  return { player: "p1", players: ["p1", "p2"], public: view(), me: {}, moves: [], version: 1, tick: 1, ...changes };
}

describe("Oberfläche von Fangen", () => {
  it("mischt Positionen zwischen zwei Ständen, springt aber bei großen Sprüngen", () => {
    const from = view({ pos: { p1: { x: 0, y: 0 }, p2: { x: 0, y: 0 } } });
    const to = view({ pos: { p1: { x: 4, y: 0 }, p2: { x: 200, y: 0 } } });
    expect(blendPositions(from, to, 0.5)).toEqual({ p1: { x: 2, y: 0 }, p2: { x: 200, y: 0 } });
  });

  it("passt das Feld mit Rand in jede Fläche ein und zentriert es", () => {
    expect(fitField(400, 240, 840, 280, 20)).toEqual({ scale: 1, left: 220, top: 20 });
    expect(fitField(400, 240, 440, 1000, 20).scale).toBe(1);
  });

  it("zeigt die Restzeit als Minuten und Sekunden", () => {
    expect(clock(1200)).toBe("1:00");
    expect(clock(1199)).toBe("1:00");
    expect(clock(19)).toBe("0:01");
    expect(clock(0)).toBe("0:00");
  });

  it("sortiert nach der kürzesten Fängerzeit", () => {
    expect(ranking(view(), players)).toEqual([
      { seat: "p2", name: "Ben", time: "1,5 s" },
      { seat: "p1", name: "Anna", time: "2,0 s" },
    ]);
  });

  it("sagt jedem Handy, was es tun soll, und nennt am Ende die Gewinner", () => {
    expect(controllerLine(snapshot(), players)).toBe("Lauf weg vor Ben!");
    expect(controllerLine(snapshot({ public: view({ catcher: "p1", frozen: 3 }) }), players)).toBe("Du bist Fänger! Gleich geht es los …");
    expect(controllerLine(snapshot({ result: { winners: ["p1", "p2"] } }), players)).toBe("Gleichstand: Anna, Ben");
    expect(resultLine(["p2"], players)).toBe("Ben gewinnt");
  });

  it("bestimmt die Richtung aus der Lage des Fingers zur Mitte des Steuerkreuzes, damit der Daumen gleiten kann", () => {
    expect(padDirection(0, -50, 10)).toBe("up");
    expect(padDirection(0, 50, 10)).toBe("down");
    expect(padDirection(-50, 10, 10)).toBe("left");
    expect(padDirection(50, -10, 10)).toBe("right");
    expect(padDirection(3, 4, 10)).toBe("none");
  });

  it("kehrt beim Loslassen einer Taste zur noch gehaltenen zurück", () => {
    let keys = pressKey([], "left");
    keys = pressKey(keys, "up");
    expect(topKey(keys)).toBe("up");
    keys = releaseKey(keys, "up");
    expect(topKey(keys)).toBe("left");
    keys = pressKey(keys, "left");
    expect(keys).toEqual(["left"]);
    expect(topKey(releaseKey(keys, "left"))).toBe("none");
  });

  it("schickt die gehaltene Richtung erneut, wenn sie auf dem Server verloren ging und nichts mehr unterwegs ist", () => {
    const moves = ["up", "down", "left", "right", "none"].map((dir) => steer(dir as "up"));
    const lost = snapshot({ moves, public: view({ dir: { p1: "none", p2: "none" } }) });
    expect(needsResend(lost, "right", 0)).toBe(true);
    expect(needsResend(lost, "right", 1)).toBe(false);
    expect(needsResend(snapshot({ moves, public: view({ dir: { p1: "right", p2: "none" } }) }), "right", 0)).toBe(false);
    expect(needsResend({ ...lost, result: { winners: ["p1"] } }, "right", 0)).toBe(false);
    expect(needsResend({ ...lost, moves: [] }, "right", 0)).toBe(false);
  });

  it("gibt jedem Sitz eine eigene Farbe", () => {
    expect(new Set(["p1", "p2", "p3", "p4", "p5", "p6"].map(seatColor)).size).toBe(6);
  });
});
