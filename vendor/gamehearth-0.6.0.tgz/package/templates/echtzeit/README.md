# Fangen

Ein Echtzeit-Spiel für [Gamehearth](https://github.com/weilers-git/gamehearth-starter), die selbst gehostete Spieleplattform. Ein Fernseher zeigt das Spielfeld, die Handys sind Controller.

## Regeln

Für 2 bis 6 Spieler.

- Alle stehen verteilt auf einem Feld. Einer wird ausgelost und ist Fänger; er hat einen Ring um seine Figur.
- Am Handy steuert jeder seine Figur mit dem Steuerkreuz. Solange ein Knopf gedrückt ist, läuft die Figur in diese Richtung.
- Der Fänger ist etwas schneller als die anderen. Berührt er jemanden, wird dieser Fänger.
- Ein neuer Fänger steht eine halbe Sekunde still, damit der alte wegkommt. Den alten Fänger kann er eine Sekunde lang nicht zurückfangen.
- Ist die Spielzeit um, gewinnt, wer insgesamt am kürzesten Fänger war. Bei Gleichstand gewinnen alle mit der kürzesten Zeit.
- Jeder Sieg zählt im eigenen Profil mit; die Bestenliste auf der Spielseite zeigt, wer am häufigsten gewonnen hat.

## Optionen

- **Spielzeit:** 30 Sekunden, 1 Minute (Standard) oder 1,5 Minuten. Der Gastgeber stellt sie in der Lobby ein.

## Ausprobieren

Voraussetzung ist Node 22 oder neuer.

```bash
npm install
npm run dev
```

Dann http://localhost:5180 öffnen. Dort stehen der Fernseher und alle Handys nebeneinander; jeden Sitz kann man selbst spielen oder einem Bot geben. Mit `npm run dev -- --host` geht es auch mit echten Handys im WLAN.

## Entwickeln

Dieses Spiel lässt sich gut mit einem KI-Agenten (Claude Code, Cursor, Copilot …) weiterbauen. Die Anleitung für den Agenten steht in [AGENTS.md](AGENTS.md).

| Befehl | Was er tut |
|---|---|
| `npm run dev` | startet das Spiel lokal mit Fernseher und allen Handys im Browser |
| `npm test` | Tests |
| `npm run typecheck` | Typprüfung |
| `npm run check` | prüft das Spiel wie die Plattform, mit Bot-Partien Tick für Tick |
| `npm run pack` | baut das Spielpaket für einen Katalog |

## Lizenz

Code unter MIT, Grafik unter CC0 (siehe [LICENSE](LICENSE) und `manifest.json`).
