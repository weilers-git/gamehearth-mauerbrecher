export {
  catcherSpeed,
  clamp,
  directions,
  fieldHeight,
  fieldWidth,
  freezeTicks,
  radius,
  runnerSpeed,
  shortestCatchers,
  startPoint,
  tag as default,
  tag,
  tagBackTicks,
  ticksPerSecond,
  touching,
} from "./game";
export type { Direction, Ids, Options, Point, Public, TagAction, TagState } from "./game";
