import { describe, expect, it } from "vitest";
import { cell, directionOfKey, finishLine, formatTime, frameMs, hudLine, menuEntries, padDirection, pressKey, recordLine, releaseKey, sharpness, speed, steerTowardLane, topKey, velocity } from "../client/src/view";

describe("Anzeige", () => {
  it("zeigt Zeiten als Minuten, Sekunden und Zehntel", () => {
    expect(formatTime(0)).toBe("0:00,0");
    expect(formatTime(83_456)).toBe("1:23,5");
    expect(formatTime(-5)).toBe("0:00,0");
  });

  it("bietet im Menü Weiter, Neu und freigeschaltete Level an", () => {
    expect(menuEntries({ format: 1, unlocked: 1, run: null }).map((entry) => [entry.label, entry.enabled])).toEqual([
      ["Spiel starten", true],
      ["Level 2 (noch gesperrt)", false],
      ["Level 3 (noch gesperrt)", false],
    ]);
    const entries = menuEntries({ format: 1, unlocked: 2, run: { start: 0, level: 1, elapsedMs: 41_200, levelMs: 5000 } });
    expect(entries[0]).toEqual({ id: "weiter", label: "Weiter: Level 2 (bisher 0:46,2)", enabled: true, level: 1 });
    expect(entries.map((entry) => entry.label)).toContain("Level 2 üben");
  });

  it("formuliert Rekord, Abschluss und Kopfzeile", () => {
    expect(recordLine(undefined)).toContain("Noch keine Bestzeit");
    expect(recordLine(75_400)).toBe("Bestzeit: 1:15,4");
    expect(finishLine(75_400, true, 75_400)).toBe("Neue Bestzeit: 1:15,4!");
    expect(finishLine(80_000, true, 75_400)).toBe("Geschafft in 1:20,0.");
    expect(finishLine(20_000, false, 75_400)).toContain("beginnst du bei Level 1");
    expect(hudLine(0, 12_300, 2, 5)).toBe("Level 1/3   0:12,3   Pilze 2/5");
  });
});

describe("Steuerung", () => {
  it("bewegt in genau eine Richtung", () => {
    expect(velocity("up")).toEqual({ x: 0, y: -speed });
    expect(velocity("none")).toEqual({ x: 0, y: 0 });
  });

  it("zieht die Figur in die Mitte der Gasse, damit sie um Ecken passt", () => {
    expect(steerTowardLane(cell * 1.5, 0)).toBe(0);
    expect(steerTowardLane(cell * 1.5 - 6, 0)).toBeGreaterThan(0);
    expect(steerTowardLane(cell * 1.5 + 6, 0)).toBeLessThan(0);
    expect(Math.abs(steerTowardLane(cell * 1.01, 0))).toBeLessThanOrEqual(speed);
  });

  it("liest das Steuerkreuz nach der Lage des Fingers zur Mitte", () => {
    expect(padDirection(2, 1, 10)).toBe("none");
    expect(padDirection(-40, 10, 10)).toBe("left");
    expect(padDirection(5, 40, 10)).toBe("down");
  });

  it("merkt sich gehaltene Tasten als Stapel", () => {
    let keys = pressKey([], "left");
    keys = pressKey(keys, "up");
    expect(topKey(keys)).toBe("up");
    keys = releaseKey(keys, "up");
    expect(topKey(keys)).toBe("left");
    expect(topKey(releaseKey(keys, "left"))).toBe("none");
  });

  it("zeichnet in der Auflösung des Geräts, höchstens dreifach", () => {
    expect(sharpness(undefined)).toBe(1);
    expect(sharpness(1.5)).toBe(2);
    expect(sharpness(2.625)).toBe(3);
    expect(sharpness(4)).toBe(3);
    expect(sharpness(0.5)).toBe(1);
  });

  it("Review 9b: liest W, A, S, D auch mit Umschalt- oder Feststelltaste", () => {
    expect(directionOfKey("a")).toBe("left");
    expect(directionOfKey("A")).toBe("left");
    expect(directionOfKey("ArrowUp")).toBe("up");
    expect(directionOfKey("constructor")).toBeUndefined();
    expect(directionOfKey("x")).toBeUndefined();
  });

  it("zählt höchstens 250 ms pro Bild, also nie mehr, als Phaser selbst nachholt", () => {
    expect(frameMs(16)).toBe(16);
    expect(frameMs(200)).toBe(200);
    expect(frameMs(5000)).toBe(250);
    expect(frameMs(-3)).toBe(0);
  });
});
