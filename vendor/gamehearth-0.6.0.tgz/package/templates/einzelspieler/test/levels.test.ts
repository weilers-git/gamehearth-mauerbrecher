import { describe, expect, it } from "vitest";
import { levelTexts, levels, parseLevel, reachable } from "../src/levels";

describe("Level", () => {
  it.each(levels.map((level, index) => [index + 1, level] as const))("Level %i ist gültig: Rand aus Wänden, ein Start, jeder Pilz erreichbar", (_number, level) => {
    expect(level.width).toBeGreaterThan(2);
    for (let x = 0; x < level.width; x++) {
      expect(level.walls).toContainEqual({ x, y: 0 });
      expect(level.walls).toContainEqual({ x, y: level.height - 1 });
    }
    for (let y = 0; y < level.height; y++) {
      expect(level.walls).toContainEqual({ x: 0, y });
      expect(level.walls).toContainEqual({ x: level.width - 1, y });
    }
    const open = reachable(level);
    for (const mushroom of level.mushrooms) {
      expect(open.has(`${mushroom.x},${mushroom.y}`), `Pilz bei ${mushroom.x},${mushroom.y}`).toBe(true);
    }
  });

  it("hat drei Level gleicher Größe, damit das Spielfeld nicht springt", () => {
    expect(levelTexts).toHaveLength(3);
    expect(new Set(levels.map((level) => `${level.width}x${level.height}`)).size).toBe(1);
  });

  it("meldet kaputte Level verständlich", () => {
    expect(() => parseLevel("###\n#S\n###")).toThrow("gleich lang");
    expect(() => parseLevel("####\n#..#\n####")).toThrow("Start S");
    expect(() => parseLevel("####\n#SS#\n####")).toThrow("genau einen Start");
    expect(() => parseLevel("####\n#S.#\n####")).toThrow("mindestens einen Pilz");
    expect(() => parseLevel("####\n#SX#\n####")).toThrow("Unbekanntes Zeichen „X“");
  });

  it("findet nicht erreichbare Pilze", () => {
    const level = parseLevel("#####\n#S#P#\n#####");
    expect(reachable(level).has("3,1")).toBe(false);
  });
});
