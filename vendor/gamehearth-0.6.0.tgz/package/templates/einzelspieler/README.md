# Pilzsuche

Ein Einzelspieler-Spiel für [Gamehearth](https://github.com/weilers-git/gamehearth-starter), die selbst gehostete Spieleplattform. Man spielt allein, auch ohne Verbindung zum Server; Spielstand und Bestzeit hebt die Plattform auf.

## Regeln

- Eine Figur läuft durch ein Labyrinth und sammelt alle Pilze ein. Gesteuert wird mit dem Steuerkreuz unten oder den Pfeiltasten (auch W, A, S, D). Solange man drückt, läuft die Figur in diese Richtung.
- Sind alle Pilze eines Levels gesammelt, ist das Level geschafft. Es gibt 3 Level.
- Die Zeit läuft, solange man in einem Level ist, und wird über die Level zusammengezählt.
- Wer alle 3 Level am Stück schafft, beginnend bei Level 1, bekommt seine Gesamtzeit als Bestzeit; kürzer ist besser.
- Zwischen den Leveln merkt sich das Spiel den Stand: Man kann aufhören und später mit dem nächsten Level weitermachen. Hört man mitten in einem Level auf, beginnt das Level beim nächsten Mal von vorn, die schon verbrauchte Zeit zählt aber mit.
- Geschaffte Level bleiben freigeschaltet und lassen sich einzeln üben; geübte Level zählen nicht für die Bestzeit.

## Ausprobieren

Voraussetzung ist Node 22 oder neuer.

```bash
npm install
npm run dev
```

Dann http://localhost:5180 öffnen. Dort steht das Spiel in einem Handy-Rahmen, darunter Spielstand und Bestzeit zum Ansehen und Löschen. Mit `npm run dev -- --host` geht es auch mit einem echten Handy im WLAN.

## Entwickeln

Dieses Spiel lässt sich gut mit einem KI-Agenten (Claude Code, Cursor, Copilot …) weiterbauen. Die Anleitung für den Agenten steht in [AGENTS.md](AGENTS.md).

| Befehl | Was er tut |
|---|---|
| `npm run dev` | startet das Spiel lokal im Browser, mit Einblick in Spielstand und Bestwerte |
| `npm test` | Tests |
| `npm run typecheck` | Typprüfung |
| `npm run check` | prüft das Spiel wie die Plattform |
| `npm run pack` | baut das Spielpaket für einen Katalog |

## Lizenz

Code unter MIT, Grafik unter CC0 (siehe [LICENSE](LICENSE) und `manifest.json`).
