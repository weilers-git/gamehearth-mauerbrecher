import type { PlayerId, PlayerInfo, PlayerSnapshot, Profile } from "@gamehearth/sdk/client";
import { cardValue, type DuelAction, type Hand, type Ids, type Options, type Public } from "../../src/index";

export type Snapshot = PlayerSnapshot<Public, Hand, DuelAction>;
export type Players = Record<PlayerId, PlayerInfo>;
export type OwnProfile = Profile<Ids>;

export function jokerCount(profile: OwnProfile): number {
  return profile.items.joker ?? 0;
}

export function profileLine(profile: OwnProfile): string {
  const jokers = jokerCount(profile);
  const wins = profile.stats.siege ?? 0;
  return `Deine Joker: ${jokers} · Deine Siege: ${wins}`;
}

export function canUseJoker(snapshot: Snapshot): boolean {
  return snapshot.moves.some((move) => move.joker === true);
}

export function nameOf(seat: PlayerId, players: Players): string {
  const info = players[seat];
  if (info === undefined) {
    return seat;
  }
  return info.you ? "Du" : info.name;
}

export function opponents(snapshot: Snapshot): PlayerId[] {
  const seats = snapshot.players;
  const own = seats.indexOf(snapshot.player);
  return [...seats.slice(own + 1), ...seats.slice(0, own)];
}

export function joinNames(names: readonly string[]): string {
  if (names.length <= 1) {
    return names[0] ?? "";
  }
  return `${names.slice(0, -1).join(", ")} und ${names.at(-1)}`;
}

export function statusLine(snapshot: Snapshot, players: Players, options: Options): string {
  if (snapshot.result !== undefined) {
    const winners = snapshot.result.winners;
    if (winners.length === 1 && winners[0] === snapshot.player) {
      return "Du gewinnst!";
    }
    if (winners.length === 1) {
      return `${nameOf(winners[0] as PlayerId, players)} gewinnt.`;
    }
    return `Gleichstand: ${joinNames(winners.map((seat) => nameOf(seat, players)))}.`;
  }
  const round = `Runde ${snapshot.public.round} von ${options.runden}`;
  if (snapshot.moves.length > 0) {
    return `${round}: Wähle eine Karte.`;
  }
  const waiting = snapshot.players.filter((seat) => !snapshot.public.played[seat]).map((seat) => nameOf(seat, players));
  if (snapshot.me.chosen !== null) {
    return `${round}: Du hast die ${snapshot.me.chosen} gelegt. Warte auf ${joinNames(waiting)}.`;
  }
  return `${round}: Warte auf ${joinNames(waiting)}.`;
}

export function revealLine(snapshot: Snapshot, players: Players): string {
  const reveal = snapshot.public.lastReveal;
  if (reveal === null) {
    return "Alle legen gleichzeitig verdeckt eine Karte. Die höchste bekommt einen Punkt.";
  }
  const cards = snapshot.players
    .map((seat) => {
      const card = reveal.cards[seat];
      if (card === undefined) {
        return `${nameOf(seat, players)} ?`;
      }
      return reveal.jokers.includes(seat) ? `${nameOf(seat, players)} ${card} mit Joker (${cardValue(card, true)})` : `${nameOf(seat, players)} ${card}`;
    })
    .join(", ");
  const winners = joinNames(reveal.winners.map((seat) => (seat === snapshot.player ? "dich" : nameOf(seat, players))));
  return `Aufgedeckt: ${cards}. Punkt für ${winners}.`;
}

export function scoreLine(seat: PlayerId, snapshot: Snapshot): string {
  const score = snapshot.public.scores[seat] ?? 0;
  return score === 1 ? "1 Punkt" : `${score} Punkte`;
}

export function seatState(seat: PlayerId, snapshot: Snapshot): string {
  if (snapshot.result !== undefined) {
    return "";
  }
  return snapshot.public.played[seat] ? "hat gelegt" : "überlegt";
}

export function sortedHand(snapshot: Snapshot): number[] {
  return [...snapshot.me.cards].sort((a, b) => a - b);
}

export function playable(snapshot: Snapshot): Set<number> {
  return new Set(snapshot.moves.map((move) => move.card));
}

export function moveFor(snapshot: Snapshot, card: number, joker = false): DuelAction | undefined {
  return snapshot.moves.find((move) => move.card === card && (move.joker === true) === joker);
}

export function rowPositions(count: number, width: number, itemWidth: number, gap: number): number[] {
  if (count === 0) {
    return [];
  }
  const step = Math.min(itemWidth + gap, (width - itemWidth) / Math.max(count - 1, 1));
  const total = step * (count - 1);
  const start = width / 2 - total / 2;
  return Array.from({ length: count }, (_, index) => start + index * step);
}

export function describeMove(move: DuelAction): string {
  return move.joker === true ? `Karte ${move.card} mit Joker legen (zählt doppelt)` : `Karte ${move.card} legen`;
}

export function describeTable(snapshot: Snapshot, players: Players): string {
  const scores = snapshot.players.map((seat) => `${nameOf(seat, players)}: ${scoreLine(seat, snapshot)}`).join(", ");
  const hand = sortedHand(snapshot).join(", ");
  return `${revealLine(snapshot, players)} Punkte: ${scores}. Deine Karten: ${hand === "" ? "keine" : hand}.`;
}
