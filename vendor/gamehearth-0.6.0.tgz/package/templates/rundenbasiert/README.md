# Kartenduell

Ein Spiel für [Gamehearth](https://github.com/weilers-git/gamehearth-starter), die selbst gehostete Spieleplattform.

## Regeln

Für 2 bis 4 Spieler. Gespielt wird mit 30 Karten, nummeriert von 1 bis 30.

- Jeder bekommt 3 Karten auf die Hand, der Rest bleibt verdeckt als Stapel.
- In jeder Runde legen alle gleichzeitig verdeckt eine Karte. Erst wenn alle gelegt haben, werden die Karten aufgedeckt.
- Die höchste Karte bekommt einen Punkt.
- Danach zieht jeder eine Karte nach.
- Nach der letzten Runde gewinnt, wer die meisten Punkte hat. Bei Gleichstand gewinnen alle mit den meisten Punkten.
- Wer gewinnt, bekommt einen Sieg und einen Joker. Beides bleibt im eigenen Profil, auch für spätere Partien; die Siege stehen in der Bestenliste auf der Spielseite.
- Wer einen Joker hat, kann eine Karte mit Joker legen: Sie zählt dann doppelt, und der Joker ist verbraucht.

## Optionen

- **Runden:** 3, 5 (Standard) oder 7. Der Gastgeber stellt sie in der Lobby ein.

## Ausprobieren

Voraussetzung ist Node 22 oder neuer.

```bash
npm install
npm run dev
```

Dann http://localhost:5180 öffnen. Dort sitzen alle Spieler nebeneinander; jeden Sitz kann man selbst spielen oder einem Bot geben.

## Entwickeln

Dieses Spiel lässt sich gut mit einem KI-Agenten (Claude Code, Cursor, Copilot …) weiterbauen. Die Anleitung für den Agenten steht in [AGENTS.md](AGENTS.md).

| Befehl | Was er tut |
|---|---|
| `npm run dev` | startet das Spiel lokal mit allen Spielern im Browser |
| `npm test` | Tests |
| `npm run typecheck` | Typprüfung |
| `npm run check` | prüft das Spiel wie die Plattform, mit hunderten Bot-Partien |
| `npm run pack` | baut das Spielpaket für einen Katalog |

## Lizenz

Code unter MIT, Grafik unter CC0 (siehe [LICENSE](LICENSE) und `manifest.json`).
