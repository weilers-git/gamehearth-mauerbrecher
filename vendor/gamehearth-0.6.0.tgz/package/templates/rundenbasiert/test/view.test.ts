import { describe, expect, it } from "vitest";
import {
  canUseJoker,
  describeMove,
  describeTable,
  joinNames,
  moveFor,
  opponents,
  profileLine,
  revealLine,
  rowPositions,
  statusLine,
  type Players,
  type Snapshot,
} from "../client/src/view";

const players: Players = {
  p1: { name: "Anna", connected: true, you: true },
  p2: { name: "Ben", connected: true, you: false },
  p3: { name: "Clara", connected: false, you: false },
};

function snapshot(extra: Partial<Snapshot> = {}): Snapshot {
  return {
    player: "p1",
    players: ["p1", "p2", "p3"],
    public: {
      round: 2,
      scores: { p1: 1, p2: 0, p3: 0 },
      played: { p1: false, p2: true, p3: false },
      lastReveal: { cards: { p1: 17, p2: 4, p3: 9 }, jokers: [], winners: ["p1"] },
      deckSize: 18,
      finished: false,
    },
    me: { cards: [21, 3, 12], chosen: null, joker: false },
    moves: [
      { type: "play", card: 21 },
      { type: "play", card: 3 },
      { type: "play", card: 12 },
    ],
    version: 4,
    ...extra,
  };
}

describe("Oberfläche", () => {
  it("sagt, was zu tun ist", () => {
    expect(statusLine(snapshot(), players, { runden: 5 })).toBe("Runde 2 von 5: Wähle eine Karte.");
    expect(statusLine(snapshot(), players, { runden: 3 })).toBe("Runde 2 von 3: Wähle eine Karte.");
    const before = snapshot();
    const waiting = snapshot({ moves: [], me: { cards: [21, 3], chosen: 12, joker: false }, public: { ...before.public, played: { p1: true, p2: true, p3: false } } });
    expect(statusLine(waiting, players, { runden: 5 })).toBe("Runde 2 von 5: Du hast die 12 gelegt. Warte auf Clara.");
  });

  it("nennt Sieger und Gleichstand", () => {
    expect(statusLine(snapshot({ result: { winners: ["p1"] } }), players, { runden: 5 })).toBe("Du gewinnst!");
    expect(statusLine(snapshot({ result: { winners: ["p2", "p3"] } }), players, { runden: 5 })).toBe("Gleichstand: Ben und Clara.");
  });

  it("zeigt die zuletzt aufgedeckten Karten", () => {
    expect(revealLine(snapshot(), players)).toBe("Aufgedeckt: Du 17, Ben 4, Clara 9. Punkt für dich.");
    expect(describeTable(snapshot(), players)).toContain("Deine Karten: 3, 12, 21.");
  });

  it("zeigt Joker im Profil, beim Aufdecken und als eigene Züge", () => {
    expect(profileLine({ items: { joker: 2 }, stats: { siege: 3 }, flags: {} })).toBe("Deine Joker: 2 · Deine Siege: 3");
    expect(profileLine({ items: {}, stats: {}, flags: {} })).toBe("Deine Joker: 0 · Deine Siege: 0");
    const before = snapshot();
    const doubled = snapshot({ public: { ...before.public, lastReveal: { cards: { p1: 17, p2: 9, p3: 4 }, jokers: ["p2"], winners: ["p2"] } } });
    expect(revealLine(doubled, players)).toBe("Aufgedeckt: Du 17, Ben 9 mit Joker (18), Clara 4. Punkt für Ben.");
    expect(canUseJoker(snapshot())).toBe(false);
    const withJoker = snapshot({ moves: [...before.moves, { type: "play", card: 21, joker: true }] });
    expect(canUseJoker(withJoker)).toBe(true);
    expect(moveFor(withJoker, 21)).toEqual({ type: "play", card: 21 });
    expect(moveFor(withJoker, 21, true)).toEqual({ type: "play", card: 21, joker: true });
    expect(moveFor(withJoker, 3, true)).toBeUndefined();
    expect(describeMove({ type: "play", card: 21, joker: true })).toBe("Karte 21 mit Joker legen (zählt doppelt)");
  });

  it("ordnet die Mitspieler ab dem eigenen Sitz", () => {
    expect(opponents(snapshot({ player: "p2" }))).toEqual(["p3", "p1"]);
    expect(joinNames(["Anna", "Ben", "Clara"])).toBe("Anna, Ben und Clara");
  });

  it("verteilt eine Reihe mittig und schiebt sie bei wenig Platz zusammen", () => {
    expect(rowPositions(1, 300, 50, 10)).toEqual([150]);
    expect(rowPositions(3, 300, 50, 10)).toEqual([90, 150, 210]);
    const tight = rowPositions(5, 200, 80, 10);
    expect(tight[0]).toBeCloseTo(40);
    expect(tight.at(-1)).toBeCloseTo(160);
  });
});
