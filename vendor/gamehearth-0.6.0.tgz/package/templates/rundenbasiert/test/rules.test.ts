import { applyMove, createMatch, playerSnapshot, type Match, type ProfileChange, type ProfileData } from "@gamehearth/sdk/platform";
import { describe, expect, it } from "vitest";
import manifest from "../manifest.json";
import { deckSize, duel, fullDeck, handSize, type DuelAction, type DuelState, type Options } from "../src";

type DuelMatch = Match<DuelState, DuelAction>;
type Profiles = Record<string, ProfileData>;

const catalog = manifest;
const empty = (): ProfileData => ({ items: {}, stats: {}, flags: {} });

function start(playerCount: number, seed = "test", options: Options = { runden: 5 }, profiles: Profiles = {}): DuelMatch {
  const created = createMatch(duel, { playerCount, seed, options, catalog, profiles });
  if (!created.ok) {
    throw new Error(created.error.message);
  }
  return created.match;
}

function playWith(match: DuelMatch, player: string, card: number, profiles: Profiles = {}, joker = false): { match: DuelMatch; changes: ProfileChange[] } {
  const action: DuelAction = joker ? { type: "play", card, joker: true } : { type: "play", card };
  const outcome = applyMove(duel, match, { player, action, now: 0 }, { catalog, profiles });
  if (!outcome.ok) {
    throw new Error(`${player} legt ${card}: ${outcome.error.code} ${outcome.error.message}`);
  }
  return { match: outcome.match, changes: outcome.changes ?? [] };
}

function play(match: DuelMatch, player: string, card: number): DuelMatch {
  return playWith(match, player, card).match;
}

function firstCard(match: DuelMatch, player: string): number {
  const card = match.state.players[player]?.cards[0];
  if (card === undefined) {
    throw new Error(`${player} hat keine Karte`);
  }
  return card;
}

function everyCard(match: DuelMatch): number[] {
  const { state } = match;
  const inHands = match.players.flatMap((player) => {
    const hand = state.players[player];
    return hand === undefined ? [] : [...hand.cards, ...(hand.chosen === null ? [] : [hand.chosen])];
  });
  const revealed = state.public.lastReveal === null ? [] : Object.values(state.public.lastReveal.cards);
  return [...inHands, ...state.secret.deck, ...revealed];
}

describe("Kartenduell", () => {
  it("teilt jedem drei Karten aus, der Rest bleibt geheim im Stapel", () => {
    const match = start(3);
    for (const player of match.players) {
      expect(match.state.players[player]?.cards).toHaveLength(handSize);
    }
    expect(match.state.secret.deck).toHaveLength(deckSize - 3 * handSize);
    expect(match.state.public.deckSize).toBe(match.state.secret.deck.length);
    expect(everyCard(match).sort((a, b) => a - b)).toEqual(fullDeck());
  });

  it("lässt alle gleichzeitig wählen und zeigt die Wahl erst, wenn alle gelegt haben", () => {
    let match = start(2);
    expect(match.moves["p1"]).toHaveLength(handSize);
    expect(match.moves["p2"]).toHaveLength(handSize);

    const card = firstCard(match, "p1");
    match = play(match, "p1", card);
    expect(match.moves["p1"]).toEqual([]);
    expect(match.state.public.played["p1"]).toBe(true);
    expect(JSON.stringify(playerSnapshot(match, "p2"))).not.toContain(`"chosen":${card}`);

    match = play(match, "p2", firstCard(match, "p2"));
    expect(match.state.public.lastReveal?.cards["p1"]).toBe(card);
    expect(match.state.public.round).toBe(2);
    expect(match.state.public.played).toEqual({ p1: false, p2: false });
  });

  it("gibt der höchsten Karte den Punkt und lässt alle nachziehen", () => {
    let match = start(2, "punkt");
    const p1 = firstCard(match, "p1");
    const p2 = firstCard(match, "p2");
    match = play(match, "p1", p1);
    match = play(match, "p2", p2);
    const winner = p1 > p2 ? "p1" : "p2";
    expect(match.state.public.lastReveal?.winners).toEqual([winner]);
    expect(match.state.public.scores[winner]).toBe(1);
    expect(match.state.players["p1"]?.cards).toHaveLength(handSize);
    expect(match.state.public.deckSize).toBe(deckSize - 2 * handSize - 2);
  });

  it.each([3, 5, 7] as const)("endet nach %i Runden, und wer die meisten Punkte hat, gewinnt", (runden) => {
    let match = start(4, "ende", { runden });
    for (let round = 1; round <= runden; round++) {
      expect(match.result).toBeUndefined();
      for (const player of match.players) {
        match = play(match, player, firstCard(match, player));
      }
    }
    expect(match.state.public.finished).toBe(true);
    const scores = match.state.public.scores;
    const best = Math.max(...Object.values(scores));
    expect(match.result?.winners).toEqual(match.players.filter((player) => scores[player] === best));
    for (const player of match.players) {
      expect(match.moves[player]).toEqual([]);
    }
  });
});

describe("Joker und Siege im Profil", () => {
  it("bietet jede Karte auch mit Joker an, aber nur, wenn das Profil einen hat", () => {
    const withJoker: Profiles = { p1: { items: { joker: 1 }, stats: {}, flags: {} } };
    const match = start(2, "joker", { runden: 5 }, withJoker);
    expect(match.moves["p1"]).toHaveLength(2 * handSize);
    expect(match.moves["p1"]?.filter((move) => move.joker === true)).toHaveLength(handSize);
    expect(match.moves["p2"]).toHaveLength(handSize);
  });

  it("verdoppelt eine Karte mit Joker und verbraucht den Joker", () => {
    const profiles: Profiles = { p1: { items: { joker: 1 }, stats: {}, flags: {} }, p2: empty() };
    const match = start(2, "doppelt", { runden: 5 }, profiles);
    const p1 = Math.min(...(match.state.players["p1"]?.cards ?? []));
    const p2 = Math.max(...(match.state.players["p2"]?.cards ?? []));
    const first = playWith(match, "p1", p1, profiles, true);
    expect(first.changes).toEqual([{ player: "p1", op: "use", id: "joker", value: 1 }]);
    const after: Profiles = { p1: empty(), p2: empty() };
    const second = playWith(first.match, "p2", p2, after);
    expect(second.match.state.public.lastReveal?.jokers).toEqual(["p1"]);
    expect(second.match.state.public.lastReveal?.winners).toEqual(2 * p1 >= p2 ? (2 * p1 === p2 ? ["p1", "p2"] : ["p1"]) : ["p2"]);
    expect(second.match.moves["p1"]?.some((move) => move.joker === true)).toBe(false);
  });

  it("gibt den Gewinnern am Ende einen Sieg und einen Joker", () => {
    let match = start(2, "sieg", { runden: 3 });
    const changes: ProfileChange[] = [];
    for (let round = 1; round <= 3; round++) {
      for (const player of match.players) {
        const step = playWith(match, player, firstCard(match, player));
        match = step.match;
        changes.push(...step.changes);
      }
    }
    const winners = match.result?.winners ?? [];
    expect(winners.length).toBeGreaterThan(0);
    expect(changes).toEqual(
      winners.flatMap((player) => [
        { player, op: "stat", id: "siege", value: 1 },
        { player, op: "add", id: "joker", value: 1 },
      ]),
    );
  });

  it("lehnt einen Zug mit Joker ab, wenn der Joker inzwischen fehlt", () => {
    const match = start(2, "weg", { runden: 5 }, { p1: { items: { joker: 1 }, stats: {}, flags: {} } });
    const card = firstCard(match, "p1");
    const outcome = applyMove(duel, match, { player: "p1", action: { type: "play", card, joker: true }, now: 0 }, { catalog, profiles: { p1: empty() } });
    expect(outcome.ok).toBe(false);
    expect(outcome.ok ? undefined : outcome.error.code).toBe("missing-item");
  });
});
