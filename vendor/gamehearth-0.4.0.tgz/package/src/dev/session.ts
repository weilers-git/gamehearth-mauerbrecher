import { randomBytes } from "node:crypto";
import { canonicalJson, playerSnapshot, screenSnapshot, seatIds, tickMs, type AnyGameState, type InputResult, type Match, type MoveResult, type Move } from "@gamehearth/sdk/platform";
import type { Expected } from "../sandbox/outcome";
import type { GuestFunction, SandboxResult } from "../sandbox/sandbox";
import type { DevProblem, SessionView } from "./view";

export interface SandboxCaller {
  call(fn: GuestFunction, input: string, expected: Expected): Promise<SandboxResult>;
}

export type { DevProblem } from "./view";

export interface SessionOptions {
  engine: SandboxCaller;
  mapStack?: (stack: string) => string;
  botDelayMs?: number;
  now?: () => number;
  pick?: (count: number) => number;
  onChange?: () => void;
  log?: (problem: DevProblem) => void;
  realtime?: boolean;
  timers?: boolean;
}

export const speeds = [1, 0.5, 0.25] as const;
export const maxLagMs = 200;

export function nextDue(due: number, now: number, intervalMs: number): number {
  return Math.max(due + intervalMs, now - maxLagMs + intervalMs);
}
export const maxInputsPerSeat = 4;
export const inputsPerSecond = 30;
export const realtimeMovesShown = 40;
const botInputOdds = 5;

type AnyMatch = Match<AnyGameState, unknown>;
type Step = { ok: true; match: AnyMatch; results?: InputResult[] } | { ok: false; code: string; message: string; problem?: DevProblem };
type Pending = { seat: string; action: unknown; legal: boolean; resolve: (result: MoveResult) => void };
type Deferred = { action: unknown; legal: boolean };
type Retryable = "timeout" | "memory" | "crash";

const retryable: readonly string[] = ["timeout", "memory", "crash"] satisfies Retryable[];

function isLegal(legal: readonly unknown[], action: unknown): boolean {
  try {
    const wanted = canonicalJson(action);
    return legal.some((candidate) => canonicalJson(candidate) === wanted);
  } catch {
    return false;
  }
}

export const seatNames = ["Anna", "Ben", "Clara", "Dario", "Elif", "Finn", "Greta", "Hamid", "Ida", "Jonas", "Kim", "Lea"];

export function seatName(seat: string): string {
  const index = Number(seat.slice(1)) - 1;
  return seatNames[index] ?? `Spieler ${index + 1}`;
}

export function randomSeed(): string {
  return `dev-${randomBytes(8).toString("hex")}`;
}

export class DevSession {
  readonly #engine: SandboxCaller;
  readonly #mapStack: (stack: string) => string;
  readonly #botDelayMs: number;
  readonly #now: () => number;
  readonly #pick: (count: number) => number;
  readonly #onChange: () => void;
  readonly #log: (problem: DevProblem) => void;
  #queue: Promise<unknown> = Promise.resolve();
  #playerCount = 0;
  #seed = "";
  #moves: { move: Move<unknown>; bot: boolean }[] = [];
  #match: AnyMatch | undefined;
  #problem: DevProblem | undefined;
  #note: string | undefined;
  #bots = new Set<string>();
  #paused = new Set<string>();
  #botTimer: NodeJS.Timeout | undefined;
  #closed = false;
  #realtime: boolean;
  readonly #timers: boolean;
  #running = true;
  #speed: number = 1;
  #ticker: NodeJS.Timeout | undefined;
  #inputs: Pending[] = [];
  #deferred = new Map<string, Deferred>();
  #rate = new Map<string, number[]>();
  #holds = 0;
  #inputCount = 0;

  constructor(options: SessionOptions) {
    this.#engine = options.engine;
    this.#mapStack = options.mapStack ?? ((stack) => stack);
    this.#botDelayMs = options.botDelayMs ?? 700;
    this.#now = options.now ?? Date.now;
    this.#pick = options.pick ?? ((count) => Math.floor(Math.random() * count));
    this.#onChange = options.onChange ?? (() => {});
    this.#log = options.log ?? (() => {});
    this.#realtime = options.realtime === true;
    this.#timers = options.timers !== false;
  }

  get realtime(): boolean {
    return this.#realtime;
  }

  setRealtime(on: boolean): void {
    this.#realtime = on;
    if (!on) {
      this.#stopTicker();
    }
  }

  get match(): AnyMatch | undefined {
    return this.#match;
  }

  get problem(): DevProblem | undefined {
    return this.#problem;
  }

  newMatch(playerCount: number, seed: string = randomSeed()): Promise<void> {
    return this.#serial(async () => {
      this.#playerCount = playerCount;
      this.#seed = seed;
      this.#moves = [];
      this.#inputCount = 0;
      this.#rejectInputs("no-match", "Eine neue Partie hat begonnen");
      this.#deferred.clear();
      this.#bots = new Set([...this.#bots].filter((seat) => seatIds(playerCount).includes(seat)));
      this.#paused.clear();
      this.#note = undefined;
      this.#problem = undefined;
      const created = await this.#create();
      this.#match = created.ok ? created.match : undefined;
      this.#problem = created.ok ? undefined : created.problem;
      if (this.#problem !== undefined) {
        this.#log(this.#problem);
      }
      this.#syncTicker();
      this.#changed();
    });
  }

  reload(note?: string): Promise<void> {
    if (this.#realtime) {
      return this.newMatch(this.#playerCount, this.#seed).then(() => {
        this.#note = note ?? "Regeln neu geladen, neue Partie mit denselben Sitzen und Bots.";
        this.#changed();
      });
    }
    return this.#serial(async () => {
      const recorded = this.#moves;
      this.#problem = undefined;
      this.#paused.clear();
      const created = await this.#create();
      if (!created.ok) {
        this.#match = undefined;
        this.#moves = [];
        this.#problem = created.problem;
        this.#note = "Die neuen Regeln scheitern schon beim Aufbau der Partie.";
        if (this.#problem !== undefined) {
          this.#log(this.#problem);
        }
        this.#changed();
        return;
      }
      let match = created.match;
      const kept: typeof recorded = [];
      for (const entry of recorded) {
        const step = await this.#apply(match, entry.move);
        if (!step.ok) {
          const what = `Zug ${kept.length + 1} (${entry.move.player}: ${JSON.stringify(entry.move.action)})`;
          this.#problem =
            step.problem === undefined
              ? {
                  source: "regeln",
                  title: `Nachspielen bei ${what} gestoppt`,
                  message: `Mit den neuen Regeln ist dieser Zug nicht mehr möglich: ${step.message}. Die Partie steht jetzt davor; „Neue Partie“ fängt von vorn an.`,
                  seat: entry.move.player,
                  move: entry.move.action,
                }
              : { ...step.problem, title: `Nachspielen bei ${what} gestoppt: ${step.problem.title}` };
          break;
        }
        kept.push(entry);
        match = step.match;
      }
      this.#match = match;
      this.#moves = kept;
      const dropped = recorded.length - kept.length;
      this.#note =
        note ??
        (recorded.length === 0
          ? "Regeln neu geladen."
          : dropped === 0
            ? `Regeln neu geladen, ${kept.length} ${kept.length === 1 ? "Zug" : "Züge"} nachgespielt.`
            : `Regeln neu geladen, ${kept.length} von ${recorded.length} Zügen nachgespielt.`);
      if (this.#problem !== undefined) {
        this.#log(this.#problem);
      }
      this.#changed();
    });
  }

  move(seat: string, action: unknown, options: { expectedVersion?: number; bot?: boolean } = {}): Promise<MoveResult> {
    if (this.#realtime) {
      return this.#input(seat, action);
    }
    return this.#serial(async () => {
      const match = this.#match;
      if (match === undefined) {
        return { ok: false, code: "no-match", message: "Es läuft keine Partie" };
      }
      const move: Move<unknown> = { player: seat, action, now: this.#now(), ...(options.expectedVersion === undefined ? {} : { expectedVersion: options.expectedVersion }) };
      const step = await this.#apply(match, move);
      if (!step.ok) {
        if (step.problem !== undefined) {
          this.#problem = step.problem;
          if (options.bot === true) {
            this.#paused.add(seat);
            this.#problem = {
              ...step.problem,
              title: `${step.problem.title}; Bot von ${seat} angehalten`,
              message: `${step.problem.message}\nDer Bot von ${seat} zieht erst wieder, wenn die Regeln neu geladen sind, eine neue Partie beginnt oder er neu eingeschaltet wird.`,
            };
          }
          this.#log(this.#problem);
          this.#changed();
        } else if (step.code === "illegal-move" || step.code === "not-your-turn") {
          const problem: DevProblem = {
            source: "oberfläche",
            title: `Die Oberfläche von ${seat} hat einen Zug geschickt, der nicht erlaubt ist`,
            message: `${step.message}. Eine Oberfläche schickt nur Züge aus snapshot.moves.`,
            seat,
            move: action,
          };
          this.#log(problem);
        }
        return { ok: false, code: step.code, message: step.message };
      }
      const { expectedVersion: _ignored, ...recorded } = move;
      this.#moves.push({ move: recorded, bot: options.bot === true });
      this.#match = step.match;
      if (options.bot !== true) {
        this.#problem = undefined;
        this.#note = undefined;
      }
      this.#changed();
      return { ok: true };
    });
  }

  pause(paused: boolean): void {
    this.#running = !paused;
    if (!paused && this.#problem?.source === "regeln") {
      this.#problem = undefined;
    }
    if (this.#accepting()) {
      this.#release();
    } else {
      this.#defer();
    }
    this.#syncTicker();
    this.#changed();
  }

  async hold(): Promise<void> {
    this.#holds += 1;
    this.#stopTicker();
    await this.#queue;
  }

  unhold(): void {
    this.#holds = Math.max(0, this.#holds - 1);
    this.#syncTicker();
  }

  setSpeed(speed: number): void {
    if (!(speeds as readonly number[]).includes(speed)) {
      return;
    }
    this.#speed = speed;
    this.#stopTicker();
    this.#syncTicker();
    this.#changed();
  }

  step(): Promise<void> {
    return this.#serial(() => {
      this.#release();
      return this.#tick();
    });
  }

  setBot(seat: string, on: boolean): void {
    if (on) {
      this.#bots.add(seat);
    } else {
      this.#bots.delete(seat);
    }
    this.#paused.delete(seat);
    this.#changed();
  }

  view(): SessionView {
    const match = this.#match;
    const seats = match?.players ?? seatIds(Math.max(this.#playerCount, 0));
    const moves = this.#moves.map((entry, index) => ({ number: index + 1, seat: entry.move.player, action: entry.move.action, bot: entry.bot }));
    return {
      playerCount: this.#playerCount,
      seed: this.#seed,
      version: match?.version,
      result: match?.result,
      ...(this.#realtime
        ? {
            realtime: {
              tick: match?.tick ?? 0,
              running: this.#running && this.#problem === undefined && match !== undefined && match.result === undefined,
              speed: this.#speed,
              inputs: this.#inputCount,
            },
          }
        : {}),
      screen: match === undefined ? undefined : screenSnapshot(match),
      seats: seats.map((seat) => ({
        seat,
        name: seatName(seat),
        bot: this.#bots.has(seat),
        paused: this.#paused.has(seat),
        snapshot: match === undefined ? undefined : playerSnapshot(match, seat),
      })),
      state: match?.state,
      moves: this.#realtime ? moves.slice(-realtimeMovesShown) : moves,
      problem: this.#problem,
      note: this.#note,
    };
  }

  close(): void {
    this.#closed = true;
    clearTimeout(this.#botTimer);
    this.#stopTicker();
    this.#rejectInputs("no-match", "dev wird beendet");
  }

  async idle(): Promise<void> {
    await this.#queue;
  }

  #serial<T>(task: () => Promise<T>): Promise<T> {
    const next = this.#queue.then(task, task);
    this.#queue = next.catch(() => undefined);
    return next;
  }

  #changed(): void {
    this.#onChange();
    this.#scheduleBot();
  }

  #input(seat: string, action: unknown): Promise<MoveResult> {
    const match = this.#match;
    if (match === undefined || match.result !== undefined) {
      return Promise.resolve({ ok: false, code: match === undefined ? "no-match" : "game-over", message: "Es läuft keine Partie" });
    }
    if (!this.#allow(seat)) {
      return Promise.resolve({ ok: false, code: "rate-limited", message: `Mehr als ${inputsPerSecond} Eingaben pro Sekunde; die Plattform lehnt sie genauso ab` });
    }
    const legal = isLegal(match.moves[seat] ?? [], action);
    if (!this.#accepting()) {
      this.#deferred.delete(seat);
      this.#deferred.set(seat, { action, legal });
      return Promise.resolve({ ok: true });
    }
    const waiting = this.#inputs.filter((entry) => entry.seat === seat);
    if (waiting.length >= maxInputsPerSeat) {
      const oldest = waiting[0] as Pending;
      this.#inputs.splice(this.#inputs.indexOf(oldest), 1);
      oldest.resolve({ ok: false, code: "too-many-inputs", message: "Zu viele Eingaben auf einmal; die älteste ist verfallen" });
    }
    return new Promise((resolve) => this.#inputs.push({ seat, action, legal, resolve }));
  }

  #accepting(): boolean {
    return this.#running && this.#problem === undefined;
  }

  #allow(seat: string): boolean {
    const now = this.#now();
    const recent = (this.#rate.get(seat) ?? []).filter((at) => now - at < 1000);
    if (recent.length >= inputsPerSecond) {
      this.#rate.set(seat, recent);
      return false;
    }
    recent.push(now);
    this.#rate.set(seat, recent);
    return true;
  }

  #defer(): void {
    for (const entry of this.#inputs.splice(0)) {
      this.#deferred.delete(entry.seat);
      this.#deferred.set(entry.seat, { action: entry.action, legal: entry.legal });
      entry.resolve({ ok: true });
    }
  }

  #release(): void {
    for (const [seat, entry] of this.#deferred) {
      this.#inputs.push({ seat, action: entry.action, legal: entry.legal, resolve: () => undefined });
    }
    this.#deferred.clear();
  }

  async #run(fn: "stepMatch", input: string, expected: Expected): Promise<SandboxResult> {
    const result = await this.#engine.call(fn, input, expected);
    if (!result.ok && retryable.includes(result.failure.kind)) {
      return this.#engine.call(fn, input, expected);
    }
    return result;
  }

  async #tick(): Promise<void> {
    const match = this.#match;
    if (match === undefined || match.result !== undefined || match.tick === undefined) {
      return;
    }
    const pending = this.#inputs.splice(0);
    const inputs = pending.map((entry) => ({ player: entry.seat, action: entry.action, bot: false, legal: entry.legal }));
    for (const seat of match.players) {
      const legal = match.moves[seat] ?? [];
      if (this.#bots.has(seat) && legal.length > 0 && this.#pick(botInputOdds) === 0) {
        inputs.push({ player: seat, action: legal[this.#pick(legal.length)], bot: true, legal: true });
      }
    }
    const step = { inputs: inputs.map(({ player, action }) => ({ player, action })), now: this.#now(), dt: tickMs };
    const result = await this.#run("stepMatch", JSON.stringify({ match, step }), {
      seed: match.seed,
      players: match.players,
      version: match.version + 1,
      tick: match.tick + 1,
      inputs: inputs.length,
    });
    if (this.#match !== match) {
      for (const entry of pending) {
        entry.resolve({ ok: false, code: "no-match", message: "Eine neue Partie hat begonnen" });
      }
      return;
    }
    const outcome = this.#step(result, { tick: match.tick + 1 });
    if (!outcome.ok) {
      this.#problem = outcome.problem ?? { source: "regeln", title: `Tick ${match.tick + 1} ist gescheitert`, message: outcome.message };
      this.#problem = { ...this.#problem, title: `${this.#problem.title}; die Partie ist angehalten` };
      this.#log(this.#problem);
      for (const entry of pending) {
        entry.resolve({ ok: false, code: outcome.code, message: outcome.message });
      }
      this.#defer();
      this.#stopTicker();
      this.#changed();
      return;
    }
    const results = outcome.results ?? [];
    inputs.forEach((input, index) => {
      const answer = results[index] ?? { ok: false, code: "game-error", message: "keine Antwort auf die Eingabe" };
      if (answer.ok) {
        this.#inputCount += 1;
        this.#moves.push({ move: { player: input.player, action: input.action, now: step.now }, bot: input.bot });
      } else if (!input.bot && !input.legal && (answer.code === "illegal-move" || answer.code === "not-your-turn")) {
        this.#log({
          source: "oberfläche",
          title: `Die Oberfläche von ${input.player} hat eine Eingabe geschickt, die nicht erlaubt ist`,
          message: `${answer.message}. Eine Oberfläche schickt nur Eingaben aus snapshot.moves.`,
          seat: input.player,
          move: input.action,
        });
      }
    });
    if (this.#moves.length > realtimeMovesShown * 4) {
      this.#moves.splice(0, this.#moves.length - realtimeMovesShown);
    }
    pending.forEach((entry, index) => {
      const answer = results[index];
      entry.resolve(answer === undefined ? { ok: false, code: "game-error", message: "keine Antwort auf die Eingabe" } : answer.ok ? { ok: true } : { ok: false, code: answer.code, message: answer.message });
    });
    this.#match = outcome.match;
    if (outcome.match.result !== undefined) {
      this.#stopTicker();
    }
    this.#onChange();
  }

  #syncTicker(): void {
    const match = this.#match;
    const wanted =
      this.#realtime && this.#timers && this.#running && this.#holds === 0 && !this.#closed && match !== undefined && match.result === undefined && this.#problem === undefined;
    if (!wanted) {
      this.#stopTicker();
      return;
    }
    if (this.#ticker !== undefined) {
      return;
    }
    let busy = false;
    const interval = tickMs / this.#speed;
    let due = performance.now();
    this.#ticker = setInterval(() => {
      const now = performance.now();
      if (busy || now < due) {
        return;
      }
      due = nextDue(due, now, interval);
      busy = true;
      void this.#serial(() => this.#tick()).finally(() => {
        busy = false;
      });
    }, 10);
    this.#ticker.unref?.();
  }

  #stopTicker(): void {
    if (this.#ticker !== undefined) {
      clearInterval(this.#ticker);
      this.#ticker = undefined;
    }
  }

  #rejectInputs(code: string, message: string): void {
    for (const entry of this.#inputs.splice(0)) {
      entry.resolve({ ok: false, code, message });
    }
  }

  #scheduleBot(): void {
    if (this.#botTimer !== undefined || this.#closed || this.#realtime) {
      return;
    }
    const match = this.#match;
    if (match === undefined || match.result !== undefined) {
      return;
    }
    const seat = match.players.find((player) => this.#bots.has(player) && !this.#paused.has(player) && (match.moves[player] ?? []).length > 0);
    if (seat === undefined) {
      return;
    }
    this.#botTimer = setTimeout(() => {
      this.#botTimer = undefined;
      const current = this.#match;
      const moves = current?.moves[seat] ?? [];
      if (current === undefined || !this.#bots.has(seat) || this.#paused.has(seat) || moves.length === 0) {
        this.#scheduleBot();
        return;
      }
      void this.move(seat, moves[this.#pick(moves.length)], { expectedVersion: current.version, bot: true }).then(() => this.#scheduleBot());
    }, this.#botDelayMs);
  }

  async #create(): Promise<Step> {
    const players = seatIds(this.#playerCount);
    const result = await this.#engine.call("createMatch", JSON.stringify({ playerCount: this.#playerCount, seed: this.#seed }), {
      seed: this.#seed,
      players,
      version: 0,
      ...(this.#realtime ? { tick: 0 } : {}),
    });
    return this.#step(result);
  }

  async #apply(match: AnyMatch, move: Move<unknown>): Promise<Step> {
    const result = await this.#engine.call("applyMove", JSON.stringify({ match, move }), { seed: match.seed, players: match.players, version: match.version + 1 });
    return this.#step(result, { move });
  }

  #step(result: SandboxResult, during: { move?: Move<unknown>; tick?: number } = {}): Step {
    const move = during.move;
    if (!result.ok) {
      const problem: DevProblem = {
        source: "regeln",
        title:
          during.tick !== undefined
            ? `Tick ${during.tick} ist gescheitert`
            : move === undefined
              ? "Die Partie lässt sich nicht anlegen"
              : `Der Zug von ${move.player} ist gescheitert`,
        message: result.failure.message,
        ...(result.failure.stack === undefined ? {} : { stack: this.#mapStack(result.failure.stack) }),
        ...(move === undefined ? {} : { seat: move.player, move: move.action }),
      };
      return { ok: false, code: "game-error", message: result.failure.message, problem };
    }
    const outcome = result.outcome;
    if (outcome.ok) {
      return outcome.results === undefined
        ? { ok: true, match: outcome.match as unknown as AnyMatch }
        : { ok: true, match: outcome.match as unknown as AnyMatch, results: outcome.results };
    }
    const error = outcome.error;
    if (error.code !== "game-error") {
      return { ok: false, code: error.code, message: error.message };
    }
    const problem: DevProblem = {
      source: "regeln",
      title: `Fehler in ${error.phase ?? "den Regeln"}${error.player === undefined ? "" : ` für ${error.player}`}${during.tick === undefined ? "" : ` (Tick ${during.tick})`}`,
      message: error.message,
      ...(error.stack === undefined ? {} : { stack: this.#mapStack(error.stack) }),
      ...(move === undefined ? {} : { seat: move.player, move: move.action }),
    };
    return { ok: false, code: error.code, message: error.message, problem };
  }
}
