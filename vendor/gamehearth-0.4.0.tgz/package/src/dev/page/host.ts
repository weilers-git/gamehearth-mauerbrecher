import { bridgeVersion, parseGameMessage, tickMs, type MoveResult, type PlayerInfo } from "@gamehearth/sdk/platform";
import { formatProblem, type DevLog, type DevProblem, type DevView, type SeatView } from "../view";

interface Frame {
  seat: string;
  screen: boolean;
  root: HTMLElement;
  iframe: HTMLIFrameElement | undefined;
  holder: HTMLElement;
  bot: HTMLInputElement | undefined;
  botState: HTMLElement | undefined;
  details: HTMLDetailsElement;
  snapshot: HTMLElement;
  ready: boolean;
  sent: string | undefined;
}

const soloOnlyText = "Dieses Spiel ist ein Einzelspieler ohne Reducer (mode \"single\", server false). Es ruft connectSolo() aus @gamehearth/sdk/client auf, nicht connect().";
const noSoloText = "Dieses Spiel hat einen Reducer und läuft wie in einem Raum. connectSolo() gibt es nur für Einzelspieler ohne Reducer (mode \"single\", server false); Spiele mit Reducer rufen connect() auf.";
const screenSeat = "tv";
const single = /^\/(p\d+|tv)\/?$/.exec(location.pathname)?.[1];
const frames = new Map<string, Frame>();
let view: DevView | undefined;
let layoutKey = "";

function element<K extends keyof HTMLElementTagNameMap>(tag: K, props: Partial<HTMLElementTagNameMap[K]> = {}, ...children: (Node | string)[]): HTMLElementTagNameMap[K] {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function byId<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (node === null) {
    throw new Error(`#${id} fehlt`);
  }
  return node as T;
}

async function post(path: string, body: unknown): Promise<unknown> {
  const response = await fetch(path, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  return response.json();
}

function players(seat: string, seats: SeatView[]): Record<string, PlayerInfo> {
  const result: Record<string, PlayerInfo> = {};
  for (const entry of seats) {
    result[entry.seat] = { name: entry.bot ? `${entry.name} (Bot)` : entry.name, connected: true, you: entry.seat === seat };
  }
  return result;
}

function hasScreen(current: DevView): boolean {
  return current.game?.roles.includes("screen") === true;
}

function seatRole(current: DevView): "player" | "controller" {
  const roles = current.game?.roles ?? [];
  return roles.includes("player") || !roles.includes("controller") ? "player" : "controller";
}

function frameSnapshot(current: DevView, frame: Frame): unknown {
  if (frame.screen) {
    return current.session.screen;
  }
  return current.session.seats.find((entry) => entry.seat === frame.seat)?.snapshot;
}

function sendUpdate(frame: Frame): void {
  const current = view;
  if (current?.solo !== undefined) {
    return;
  }
  const snapshot = current === undefined ? undefined : frameSnapshot(current, frame);
  if (!frame.ready || current === undefined || snapshot === undefined || frame.iframe?.contentWindow == null) {
    return;
  }
  const speed = current.session.realtime?.speed ?? 1;
  const pace = speed === 1 ? {} : { tickMs: tickMs / speed };
  const update = frame.screen
    ? { gamehearth: bridgeVersion, type: "update", seat: null, role: "screen", snapshot, players: players("", current.session.seats), online: true, ...pace }
    : { gamehearth: bridgeVersion, type: "update", seat: frame.seat, role: seatRole(current), snapshot, players: players(frame.seat, current.session.seats), online: true, ...pace };
  const serialized = JSON.stringify(update);
  if (serialized === frame.sent) {
    return;
  }
  frame.sent = serialized;
  frame.iframe.contentWindow.postMessage(update, "*");
}

function loadFrame(frame: Frame): void {
  const current = view;
  frame.ready = false;
  frame.sent = undefined;
  frame.iframe?.remove();
  frame.iframe = undefined;
  frame.holder.replaceChildren();
  if (current === undefined || !current.client.ready) {
    frame.holder.append(element("p", { className: "placeholder" }, current?.client.note ?? "Die Oberfläche wird gebaut …"));
    return;
  }
  if (frameSnapshot(current, frame) === undefined) {
    frame.holder.append(element("p", { className: "placeholder" }, "Keine Partie. Der Fehler steht oben."));
    return;
  }
  const iframe = element("iframe", { title: frame.screen ? "Spiel auf dem Fernseher" : `Spiel für ${frame.seat}` });
  iframe.setAttribute("sandbox", "allow-scripts");
  iframe.src = `/game/index.html?sitz=${frame.seat}&v=${current.client.version}`;
  frame.iframe = iframe;
  frame.holder.append(iframe);
}

function buildScreenFrame(root: HTMLElement): void {
  const snapshot = element("pre", { className: "json" });
  const holder = element("div", { className: "frame" });
  const bar = element(
    "div",
    { className: "bar" },
    element("strong", {}, "Fernseher"),
    single === undefined ? element("a", { href: "/tv", target: "_blank" }, "eigenes Fenster") : element("a", { href: "/" }, "alle Sitze"),
  );
  const details = element("details", {}, element("summary", {}, "Snapshot des Fernsehers"), snapshot);
  details.addEventListener("toggle", refreshInsight);
  const article = element("article", { className: "seat tv" }, bar, holder, details);
  root.append(article);
  const frame: Frame = { seat: screenSeat, screen: true, root: article, iframe: undefined, holder, bot: undefined, botState: undefined, details, snapshot, ready: false, sent: undefined };
  frames.set(screenSeat, frame);
  loadFrame(frame);
}

function buildSoloFrame(current: DevView, root: HTMLElement): void {
  const holder = element("div", { className: "frame" });
  const bar = element(
    "div",
    { className: "bar" },
    element("strong", {}, "Einzelspieler"),
    single === undefined ? element("a", { href: "/p1", target: "_blank" }, "eigenes Fenster") : element("a", { href: "/" }, "mit Einblick"),
  );
  const snapshot = element("pre", { className: "json" });
  const details = element("details", {}, snapshot);
  const article = element("article", { className: `seat solo-${current.solo?.screen ?? "small"}` }, bar, holder);
  root.append(article);
  const frame: Frame = { seat: "p1", screen: false, root: article, iframe: undefined, holder, bot: undefined, botState: undefined, details, snapshot, ready: false, sent: undefined };
  frames.set("p1", frame);
  loadFrame(frame);
}

function buildFrames(current: DevView): void {
  const seats = current.session.seats.filter((entry) => single === undefined || entry.seat === single);
  const root = byId("seats");
  frames.clear();
  root.replaceChildren();
  if (current.solo !== undefined) {
    buildSoloFrame(current, root);
    return;
  }
  const screen = hasScreen(current) && (single === undefined || single === screenSeat);
  if (screen) {
    buildScreenFrame(root);
  }
  if (single !== undefined && seats.length === 0 && !screen) {
    root.append(element("p", { className: "placeholder" }, `Den Sitz ${single} gibt es in dieser Partie nicht. `, element("a", { href: "/" }, "Alle Sitze")));
    return;
  }
  for (const entry of seats) {
    const bot = element("input", { type: "checkbox", checked: entry.bot });
    bot.addEventListener("change", () => void post("/__dev/bot", { seat: entry.seat, on: bot.checked }));
    const snapshot = element("pre", { className: "json" });
    const holder = element("div", { className: "frame" });
    const botState = element("span", { className: "paused" });
    const bar = element(
      "div",
      { className: "bar" },
      element("strong", {}, `${entry.seat} · ${entry.name}`),
      element("label", {}, bot, " Bot", botState),
      single === undefined ? element("a", { href: `/${entry.seat}`, target: "_blank" }, "eigenes Fenster") : element("a", { href: "/" }, "alle Sitze"),
    );
    const details = element("details", {}, element("summary", {}, `Snapshot von ${entry.seat}`), snapshot);
    details.addEventListener("toggle", refreshInsight);
    const article = element("article", { className: "seat" }, bar, holder, details);
    root.append(article);
    const frame: Frame = { seat: entry.seat, screen: false, root: article, iframe: undefined, holder, bot, botState, details, snapshot, ready: false, sent: undefined };
    frames.set(entry.seat, frame);
    loadFrame(frame);
  }
}

function renderProblems(current: DevView): void {
  const solo: DevProblem[] = current.solo?.problem === undefined ? [] : [{ source: "oberfläche", title: "Spielstand-Datei", message: current.solo.problem }];
  const problems: DevProblem[] = [...(current.session.problem === undefined ? [] : [current.session.problem]), ...current.problems, ...solo];
  const box = byId("problems");
  box.replaceChildren(
    ...problems.map((problem) => {
      const text = formatProblem(problem);
      const copy = element("button", { type: "button", textContent: "Kopieren" });
      copy.addEventListener("click", () => {
        void navigator.clipboard?.writeText(text).then(() => {
          copy.textContent = "Kopiert";
        });
      });
      return element("section", { className: `problem ${problem.source}` }, element("pre", {}, text), copy);
    }),
  );
  box.hidden = problems.length === 0;
  const note = byId("note");
  note.textContent = current.session.note ?? "";
  note.hidden = current.session.note === undefined;
}

function renderLogs(logs: DevLog[]): void {
  const list = byId("logs");
  list.replaceChildren(...logs.map((log) => element("li", { className: log.level }, `${log.seat} ${log.level}: ${log.text}`)));
  byId("log-box").hidden = logs.length === 0;
}

function renderToolbar(current: DevView): void {
  document.title = `${current.game?.name ?? "Spiel"} · Gamehearth dev`;
  byId("game-name").textContent = current.game?.name ?? "Spiel";
  const select = byId<HTMLSelectElement>("count");
  const counts = current.game?.counts ?? [];
  const wanted = String(current.session.playerCount);
  const options = counts.map((count) => String(count));
  if (options.join(",") !== [...select.options].map((option) => option.value).join(",")) {
    select.replaceChildren(...options.map((value) => element("option", { value, textContent: `${value} Spieler` })));
  }
  if (document.activeElement !== select) {
    select.value = wanted;
  }
  const session = current.session;
  const realtime = session.realtime;
  if (current.solo !== undefined) {
    byId("status").textContent = "Einzelspieler ohne Reducer";
    return;
  }
  const status =
    session.result !== undefined
      ? "Partie vorbei"
      : session.version === undefined
        ? "keine Partie"
        : realtime !== undefined
          ? `Tick ${realtime.tick} (${(realtime.tick / 20).toFixed(1)} s Spielzeit), ${realtime.inputs} ${realtime.inputs === 1 ? "Eingabe" : "Eingaben"}${realtime.running ? "" : ", angehalten"}`
          : `Stand ${session.version}, ${session.moves.length} ${session.moves.length === 1 ? "Zug" : "Züge"}`;
  byId("status").textContent = status;
  for (const id of ["pause", "step", "speed"]) {
    byId(id).hidden = realtime === undefined;
  }
  if (realtime !== undefined) {
    byId("pause").textContent = realtime.running ? "Anhalten" : "Weiter";
    byId<HTMLButtonElement>("step").disabled = realtime.running || session.result !== undefined;
    const speed = byId<HTMLSelectElement>("speed");
    if (document.activeElement !== speed) {
      speed.value = String(realtime.speed);
    }
  }
}

function refreshInsight(): void {
  if (view !== undefined) {
    renderInsight(view);
  }
}

function renderSolo(current: DevView): void {
  const solo = current.solo;
  document.body.classList.toggle("solo", solo !== undefined);
  byId("solo-box").hidden = solo === undefined;
  if (solo === undefined) {
    return;
  }
  byId("solo-saved").textContent = JSON.stringify(solo.saved ?? null, null, 2);
  byId("solo-best").textContent = JSON.stringify(solo.best, null, 2);
  byId("solo-file").textContent = solo.file;
}

function renderInsight(current: DevView): void {
  renderSolo(current);
  const session = current.session;
  if (byId<HTMLDetailsElement>("state-box").open || session.realtime === undefined) {
    byId("state").textContent = JSON.stringify(session.state ?? null, null, 2);
  }
  byId("seed").textContent = session.seed;
  byId("moves").replaceChildren(...session.moves.map((move) => element("li", {}, `${move.seat}${move.bot ? " (Bot)" : ""}: ${JSON.stringify(move.action)}`)));
  for (const entry of session.seats) {
    const frame = frames.get(entry.seat);
    if (frame !== undefined) {
      if (frame.details.open) {
        frame.snapshot.textContent = JSON.stringify(entry.snapshot ?? null, null, 2);
      }
      if (frame.bot !== undefined && frame.botState !== undefined) {
        frame.bot.checked = entry.bot;
        frame.botState.textContent = entry.bot && entry.paused ? " (angehalten)" : "";
      }
    }
  }
  const tv = frames.get(screenSeat);
  if (tv !== undefined && tv.details.open) {
    tv.snapshot.textContent = JSON.stringify(session.screen ?? null, null, 2);
  }
}

function render(next: DevView): void {
  const previous = view;
  view = next;
  const key = JSON.stringify([next.session.seats.map((entry) => entry.seat), next.session.version === undefined, next.client.ready, next.game?.roles ?? []]);
  if (key !== layoutKey) {
    layoutKey = key;
    buildFrames(next);
  } else if (
    previous !== undefined &&
    (previous.client.version !== next.client.version ||
      previous.session.seed !== next.session.seed ||
      (next.session.version ?? 0) < (previous.session.version ?? 0) ||
      (next.session.realtime?.tick ?? 0) < (previous.session.realtime?.tick ?? 0))
  ) {
    for (const frame of frames.values()) {
      loadFrame(frame);
    }
  }
  renderToolbar(next);
  renderProblems(next);
  renderLogs(next.logs);
  renderInsight(next);
  for (const frame of frames.values()) {
    sendUpdate(frame);
  }
}

addEventListener("message", (event: MessageEvent) => {
  const frame = [...frames.values()].find((candidate) => candidate.iframe !== undefined && candidate.iframe.contentWindow === event.source);
  if (frame === undefined) {
    return;
  }
  const data = event.data as Record<string, unknown> | null;
  if (data !== null && typeof data === "object" && data["gamehearthDev"] === 1 && data["type"] === "log") {
    void post("/__dev/log", { seat: frame.seat, level: data["level"], text: data["text"], stack: data["stack"] });
    return;
  }
  const message = parseGameMessage(event.data);
  if (message === undefined) {
    return;
  }
  if (view?.solo !== undefined) {
    handleSolo(frame, message);
    return;
  }
  if (message.type === "ready") {
    frame.ready = true;
    frame.sent = undefined;
    sendUpdate(frame);
    return;
  }
  const target = frame.iframe?.contentWindow;
  if (message.type === "solo-ready") {
    target?.postMessage({ gamehearth: bridgeVersion, type: "refused", message: noSoloText }, "*");
    return;
  }
  if (message.type !== "move") {
    target?.postMessage({ gamehearth: bridgeVersion, type: "result", id: message.id, ok: false, code: "not-solo", message: noSoloText }, "*");
    return;
  }
  if (frame.screen) {
    target?.postMessage({ gamehearth: bridgeVersion, type: "result", id: message.id, ok: false, code: "screen", message: "Ein Fernseher kann keine Züge machen." }, "*");
    return;
  }
  void (post("/__dev/move", { seat: frame.seat, action: message.action, expectedVersion: message.expectedVersion }) as Promise<MoveResult>).then(
    (result) => target?.postMessage({ gamehearth: bridgeVersion, type: "result", id: message.id, ...result }, "*"),
    (error: unknown) =>
      target?.postMessage({ gamehearth: bridgeVersion, type: "result", id: message.id, ok: false, code: "offline", message: error instanceof Error ? error.message : String(error) }, "*"),
  );
});

function soloReply(frame: Frame, message: unknown): void {
  frame.iframe?.contentWindow?.postMessage(message, "*");
}

interface SoloAnswer {
  ok: boolean;
  code?: string;
  message?: string;
  solo?: { saved: unknown; best: Record<string, number> };
}

async function soloAction(body: Record<string, unknown>): Promise<SoloAnswer> {
  try {
    return (await post("/__dev/solo", body)) as SoloAnswer;
  } catch (error) {
    return { ok: false, code: "offline", message: error instanceof Error ? error.message : String(error) };
  }
}

function handleSolo(frame: Frame, message: NonNullable<ReturnType<typeof parseGameMessage>>): void {
  if (message.type === "ready") {
    soloReply(frame, { gamehearth: bridgeVersion, type: "refused", message: soloOnlyText });
    return;
  }
  if (message.type === "solo-ready") {
    frame.ready = true;
    void fetch("/__dev/view")
      .then((response) => response.json() as Promise<DevView>)
      .then((current) => soloReply(frame, { gamehearth: bridgeVersion, type: "solo", saved: current.solo?.saved ?? null, best: current.solo?.best ?? {} }));
    return;
  }
  if (message.type === "move") {
    soloReply(frame, {
      gamehearth: bridgeVersion,
      type: "result",
      id: message.id,
      ok: false,
      code: "solo-game",
      message: "Einzelspieler ohne Reducer haben keine Züge; Spielstand und Bestwerte gehen über game.save() und game.record().",
    });
    return;
  }
  if (message.problem !== undefined) {
    soloReply(frame, { gamehearth: bridgeVersion, type: "result", id: message.id, ok: false, code: message.type === "save" ? "invalid-save" : "invalid-stat", message: message.problem });
    return;
  }
  const body = message.type === "save" ? { action: "save", data: message.data } : { action: "record", stat: message.stat, value: message.value };
  void soloAction(body).then((result) => {
    if (result.ok && message.type === "record" && result.solo !== undefined) {
      soloReply(frame, { gamehearth: bridgeVersion, type: "solo", saved: result.solo.saved ?? null, best: result.solo.best });
    }
    soloReply(
      frame,
      result.ok
        ? { gamehearth: bridgeVersion, type: "result", id: message.id, ok: true }
        : { gamehearth: bridgeVersion, type: "result", id: message.id, ok: false, code: result.code ?? "platform-error", message: result.message ?? "Fehler in dev" },
    );
  });
}

function reloadSolo(): void {
  for (const frame of frames.values()) {
    loadFrame(frame);
  }
}

function start(): void {
  byId("solo-reload").addEventListener("click", reloadSolo);
  byId("solo-clear-save").addEventListener("click", () => void soloAction({ action: "clear-save" }).then(reloadSolo));
  byId("solo-clear-best").addEventListener("click", () => void soloAction({ action: "clear-best" }).then(reloadSolo));
  if (single !== undefined) {
    document.body.classList.add("single");
  }
  byId("new").addEventListener("click", () => void post("/__dev/new", { playerCount: Number(byId<HTMLSelectElement>("count").value) }));
  byId("count").addEventListener("change", () => void post("/__dev/new", { playerCount: Number(byId<HTMLSelectElement>("count").value) }));
  byId("pause").addEventListener("click", () => void post("/__dev/pause", { paused: view?.session.realtime?.running === true }));
  byId("step").addEventListener("click", () => void post("/__dev/step", {}));
  byId("state-box").addEventListener("toggle", refreshInsight);
  byId("speed").addEventListener("change", () => void post("/__dev/speed", { speed: Number(byId<HTMLSelectElement>("speed").value) }));
  const events = new EventSource("/__dev/events");
  events.addEventListener("message", (event) => render(JSON.parse(event.data as string) as DevView));
  events.addEventListener("error", () => {
    byId("status").textContent = "Verbindung zu gamehearth dev unterbrochen …";
  });
}

start();
