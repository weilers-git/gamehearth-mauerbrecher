import { describe, expect, it } from "vitest";
import { canStart, finishLevel, freshSave, levelCount, readSave, startRun, type Save } from "../src/rules";

describe("Spielstand lesen", () => {
  it("beginnt ohne Spielstand neu", () => {
    expect(readSave(undefined)).toEqual({ format: 1, unlocked: 1, run: null });
  });

  it("übernimmt einen gültigen Spielstand", () => {
    const save = { format: 1, unlocked: 2, run: { start: 0, level: 1, elapsedMs: 12_345 } };
    expect(readSave(save)).toEqual(save);
  });

  it("beginnt bei unbekanntem oder kaputtem Format neu, statt abzustürzen", () => {
    expect(readSave({ format: 2, unlocked: 3, run: null })).toEqual(freshSave());
    expect(readSave({ format: 1, unlocked: 99, run: null })).toEqual(freshSave());
    expect(readSave("Level 3")).toEqual(freshSave());
    expect(readSave({ format: 1, unlocked: 2, run: { start: 0, level: 7, elapsedMs: 0 } })).toEqual({ format: 1, unlocked: 2, run: null });
  });
});

describe("Durchgang", () => {
  it("schaltet beim Durchspielen die Level frei und zählt die Zeit zusammen", () => {
    let save = startRun(freshSave(), 0);
    let outcome = finishLevel(save, 20_000);
    expect(outcome.finished).toBeUndefined();
    expect(outcome.save).toEqual({ format: 1, unlocked: 2, run: { start: 0, level: 1, elapsedMs: 20_000 } });
    save = outcome.save;
    outcome = finishLevel(save, 25_000);
    save = outcome.save;
    outcome = finishLevel(save, 30_400);
    expect(outcome.finished).toEqual({ totalMs: 75_400, ranked: true });
    expect(outcome.save).toEqual({ format: 1, unlocked: levelCount, run: null });
  });

  it("zählt Üben ab einem späteren Level nicht für die Bestzeit", () => {
    let save: Save = { format: 1, unlocked: 3, run: null };
    save = startRun(save, 1);
    save = finishLevel(save, 10_000).save;
    expect(finishLevel(save, 10_000).finished).toEqual({ totalMs: 20_000, ranked: false });
  });

  it("startet nur freigeschaltete Level", () => {
    expect(canStart(freshSave(), 0)).toBe(true);
    expect(canStart(freshSave(), 1)).toBe(false);
    expect(() => startRun(freshSave(), 2)).toThrow("noch nicht freigeschaltet");
  });

  it("verlangt einen laufenden Durchgang zum Beenden eines Levels", () => {
    expect(() => finishLevel(freshSave(), 1000)).toThrow("kein Durchgang");
  });
});
