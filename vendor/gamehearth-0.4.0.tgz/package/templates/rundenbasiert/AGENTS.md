# Anleitung für KI-Agenten

Dieses Repo ist ein Spiel für **Gamehearth**, eine selbst gehostete Spieleplattform. Mehrere Leute spielen an ihren eigenen Geräten im Browser; die Spielregeln laufen auf dem Server, die Oberfläche läuft im Browser jedes Spielers. Du baust hier mit einer Person zusammen ein Spiel. Lies diese Datei ganz, bevor du etwas änderst.

## Mit wem du arbeitest

Die Person kann vermutlich nicht programmieren. Sie kennt ihr Spiel, nicht den Code.

- Sprich über Spielregeln, nicht über Code. Frag nach, was passieren soll („Was passiert, wenn der Stapel leer ist?“), nicht wie es gebaut wird.
- Kläre die Regeln vollständig, bevor du sie baust: Spielerzahl, Ablauf eines Zugs, wer was sieht, wann das Spiel endet, wer gewinnt, was bei Gleichstand gilt. Schreib die Regeln in Alltagssprache in die `README.md` und lass sie bestätigen.
- Arbeite in kleinen Schritten und zeig nach jedem Schritt etwas zum Ausprobieren (`npm run dev`, siehe unten). Sag in einem Satz, was sich geändert hat und was die Person ausprobieren soll.
- Fachwörter nur mit Erklärung. Fehlermeldungen übersetzt du in einen Satz, was nicht stimmt und was du dagegen tust.
- Vor dem ersten Veröffentlichen fragst du nach Lizenz und Namen (siehe „Veröffentlichen“).

## Aufbau

| Pfad | Inhalt |
|---|---|
| `manifest.json` | Name, Version, Spielerzahl, Lizenz des Spiels |
| `src/game.ts` | die Spielregeln (Reducer), laufen auf dem Server |
| `src/index.ts` | exportiert das Spiel als `default` |
| `client/src/main.ts` | verbindet die Oberfläche mit der Plattform und startet Phaser |
| `client/src/scene.ts` | zeichnet das Spiel mit Phaser 4 |
| `client/src/view.ts` | alles, was die Oberfläche entscheidet, ohne Phaser (Texte, Reihenfolge, Positionen); gut testbar |
| `client/src/access.ts` | unsichtbare Knöpfe für Tastatur und Screenreader, eine pro erlaubtem Zug |
| `test/` | Tests für Regeln und Oberflächenlogik (Vitest) |
| `dist/client/` | die gebaute Oberfläche (entsteht durch `npm run build`, nicht von Hand ändern) |

Die Vorlage enthält ein kleines Beispielspiel, **Kartenduell**: Alle legen gleichzeitig verdeckt eine Karte, die höchste bekommt einen Punkt, nach fünf Runden gewinnt, wer die meisten Punkte hat. Es zeigt die wichtigsten Muster. Ersetze es vollständig durch das Spiel der Person (siehe „Das Beispiel ersetzen“).

## Befehle

| Befehl | Wofür |
|---|---|
| `npm run dev` | startet das Spiel lokal unter http://localhost:5180 mit allen Spielern nebeneinander |
| `npm test` | Tests |
| `npm run typecheck` | Typprüfung von Regeln und Oberfläche |
| `npm run check` | prüft das Spiel wie die Plattform: Manifest, Lizenz, hunderte Partien mit Zufallsbots, Lecks, Determinismus, Lauf in der Server-Sandbox |
| `npm run pack` | baut das Spielpaket `dist/<id>-<version>.zip`, nur wenn `check` keine Fehler meldet |

`npm run dev` läuft, bis man es beendet. Starte es im Hintergrund und lies seine Ausgabe: Die Adresse steht dort (meist http://localhost:5180; ist der Port belegt, etwa weil `dev` schon läuft, ein anderer), und Fehler aus den Regeln und aus der Oberfläche stehen dort als Textblock, den du direkt beheben kannst. Läuft schon ein `dev` für dieses Spiel, nutze es weiter, statt ein zweites zu starten. Die Person öffnet die Adresse im Browser. Ändern sich Regeln oder Oberfläche, lädt `dev` von selbst neu und spielt die laufende Partie mit dem neuen Code nach. Beende `dev` am Ende samt Kindprozessen (unter Windows etwa `taskkill /T /F` auf den Prozess an dem Port aus der Ausgabe).

### Die Oberfläche prüfen

Die Oberfläche läuft in `dev` so abgeschottet wie auf der Plattform: in einem Sandbox-iframe ohne eigene Origin, auch unter den Adressen einzelner Sitze (`/p1`). Manche eingebauten Browser von KI-Werkzeugen laden solche iframes nicht (etwa der Browser-Bereich der Claude-App: die Rahmen bleiben leer, die Anfragen scheitern mit `net::ERR_BLOCKED_BY_CLIENT`). Dort läuft der Code der Oberfläche gar nicht; ein Terminal ohne Fehler beweist dann nichts. Was hilft:

- Hast du Playwright oder einen Chrome mit Fernsteuerung, bediene die Seite selbst. Mit Playwright erreichst du einen Rahmen mit `page.locator(".seat").nth(0).frameLocator("iframe")`. Über das DevTools-Protokoll von Chrome fehlen die abgeschotteten Rahmen in `Page.getFrameTree`, weil sie in einem eigenen Prozess laufen; du erreichst sie mit `Target.setAutoAttach({ autoAttach: true, flatten: true, waitForDebuggerOnStart: false })`. In jedem Rahmen gibt es die unsichtbaren Knöpfe aus `client/src/access.ts` (Gruppe „Deine Züge“).
- Sobald ein Browser die Rahmen wirklich lädt, stehen Fehler und `console.log` der Oberfläche mit Sitz und Stelle im Quelltext im Terminal von `dev`. Lies sie dort.
- Was die Oberfläche entscheidet (Texte, welcher Tipp welcher Zug ist, Positionen), gehört nach `client/src/view.ts` und wird in `test/view.test.ts` getestet. Je mehr dort steht, desto weniger musst du im Browser nachsehen.
- Konntest du die Oberfläche nicht selbst sehen, sag das bei der Übergabe ausdrücklich und bitte die Person, http://localhost:5180 in ihrem normalen Browser zu öffnen und zu sagen, was sie sieht. Das ist ohnehin der wichtigste Test.

## Arbeitsablauf

1. Regeln mit der Person klären und in die `README.md` schreiben.
2. Den Zustand entwerfen: Was sehen alle (`public`), was sieht nur ein Spieler (`players[sitz]`), was sieht niemand (`secret`)?
3. `src/game.ts` schreiben, dazu Tests in `test/rules.test.ts` für jede Regel, besonders für Sonderfälle und das Ende.
4. `npm test` und `npm run typecheck`.
5. `npm run check`, bis keine Fehler mehr kommen. Warnungen lesen und bewusst entscheiden.
6. Die Oberfläche anpassen: erst `client/src/view.ts` (mit Tests in `test/view.test.ts`), dann `client/src/scene.ts`.
7. `npm run dev`, die Person spielt es aus. Rückmeldung einarbeiten, ab Schritt 3 wiederholen.

Vor jeder Übergabe an die Person müssen `npm test`, `npm run typecheck` und `npm run check` ohne Fehler durchlaufen.

## Die wichtigsten Regeln für `src/`

Die Spielregeln sind ein **Reducer**: vier reine Funktionen in `defineGame` aus `@gamehearth/sdk`.

```ts
setup({ players, random })            // Startzustand; players = ["p1", "p2", …]
legalMoves(state, player)             // alle Züge, die dieser Sitz gerade machen darf (Array, leer = darf nicht)
apply(state, action, { player, players, random, now })  // Zug anwenden; state direkt ändern ist erlaubt
result(state)                         // undefined, solange es läuft; sonst { winners: ["p2"] }
```

1. **Kein `Math.random()`, kein `Date.now()`, kein `new Date()`.** Zufall nur über `random` (`random.int(1, 6)`, `random.pick(liste)`, `random.shuffle(liste)` gibt eine gemischte Kopie zurück), Zeit nur über `ctx.now`. Jede Partie muss sich aus Seed und Zügen exakt wiederholen lassen.
2. **Der Zustand ist reines JSON** mit genau drei Bereichen: `public` (sehen alle), `players` (ein Eintrag pro Sitz, sieht nur dieser Spieler), `secret` (sieht niemand). Kein `Set`, keine `Map`, kein `Date`, keine Klassen, kein `undefined` in Arrays.
3. **Leg jede Information in den richtigen Bereich.** Die Plattform filtert danach, was welches Gerät bekommt. Handkarten gehören in `players[sitz]`, der Stapel in `secret`. Eine verdeckte Wahl (wie im Beispiel) liegt beim Spieler, bis alle gewählt haben, und wandert erst dann nach `public`.
4. **Züge verraten nichts.** Alles, was in `legalMoves` steht, geht an den Client dieses Spielers. `{ type: "draw" }` ist richtig, `{ type: "draw", card: 17 }` verrät die oberste Karte des Stapels.
5. **Wer dran ist, steht in `public`.** Die Plattform sagt niemandem, wer gerade Züge hat. Die Oberfläche liest es aus dem Zustand.
6. **`apply` bekommt nur erlaubte Züge.** Prüf darin nicht noch einmal, ob ein Zug erlaubt ist; das macht die Plattform mit `legalMoves`.
7. **Kann niemand mehr ziehen, muss `result` ein Ergebnis liefern.** Sonst hängt die Partie. Unentschieden: mehrere Gewinner; alle verloren: `{ winners: [] }`.
8. **Sitze statt Namen.** Spieler heißen `p1`, `p2`, …; Namen gibt es nur in der Oberfläche über `players`. Die Reihenfolge von `players` ist die Zugreihenfolge.
9. **Keine Variablen außerhalb der Funktionen, die sich ändern.** Auf dem Server laufen viele Partien im selben Modul.
10. **Nur die Sprache selbst.** Die Regeln laufen auf dem Server in QuickJS: kein `console`, kein `structuredClone`, kein `Intl`, kein Netz, keine Dateien. Importieren darfst du nur Dateien aus diesem Ordner und `@gamehearth/sdk`, keine npm-Pakete mit Node-Funktionen.
11. **`setup` muss die Spielerzahl nicht prüfen.** Die Plattform startet nur mit einer Zahl aus `manifest.json`.

### Muster

Gibt es nichts Verdecktes (etwa bei Brettspielen), bekommt jeder Sitz ein leeres Objekt, und `secret` ist auch leer:

```ts
type Board = GameState<Public, Record<string, never>, Record<string, never>>;

setup({ players }) {
  return {
    public: { /* … */ },
    players: Object.fromEntries(players.map((player) => [player, {}])),
    secret: {},
  };
}
```

Reihum ziehen: Wer dran ist, steht in `public`; nur dieser Sitz hat Züge. `legalMoves` bekommt die Liste der Sitze nicht; die Reihenfolge ist `Object.keys(state.players)` (immer `p1`, `p2`, … in dieser Reihenfolge), oder du legst sie in `public`. Wer ausgeschieden ist, wird beim Weitergeben übersprungen; denk an den Fall, dass nur noch einer übrig ist.

```ts
legalMoves(state, player) {
  if (state.public.winner !== null || player !== state.public.current) {
    return [];
  }
  return freeColumns(state).map((column) => ({ type: "drop", column }));
},

apply(state, action, { player, players }) {
  // … Zug ausführen …
  state.public.current = players[(players.indexOf(player) + 1) % players.length]!;
},
```

Alle gleichzeitig verdeckt wählen: Die Wahl liegt beim Spieler (`players[sitz]`), `public` sagt nur, wer schon gewählt hat; erst wenn alle gewählt haben, wandert alles nach `public`. So macht es das Beispiel in `src/game.ts`.

Wer anfängt, ist bei vielen Spielen ein Vorteil. Soll es zufällig sein, lost `setup` mit `random.pick(players)` aus.

Kartenspiele:

- **Gleiche Karten bekommen eigene Namen**, etwa `katze-1` und `katze-2` statt zweimal `katze`. Sonst hält `check` gleiche Karten bei zwei Spielern für eine Kopie und warnt, und echte Lecks fallen schwerer auf. Texte unter 2 Zeichen und Zahlen erkennt die Leck-Prüfung gar nicht; verdeckte Karten als Texte wie `herz-7` sind deshalb sicherer als Zahlen (das Kartenduell nutzt der Einfachheit halber Zahlen).
- **Aus einer verdeckten Hand ziehen** (etwa beim Nachbarn): Der Zug nennt nur den Platz, `{ type: "draw", slot: 2 }`, nie die Karte. Die Zahl der Züge hängt nur von der öffentlichen Kartenzahl ab. Mische die verdeckte Hand in `apply` mit `random.shuffle`, bevor du die Karte am Platz nimmst, sonst verrät eine sortierte Hand, was wo liegt.
- **Was ein Spieler verloren hat**, muss nicht im Zustand stehen. Seine Oberfläche kann es aus seiner Hand vorher und nachher ausrechnen. Eine Kopie bei zwei Spielern wäre ein Leck oder zumindest eine Warnung.

## Die Oberfläche

- Die Oberfläche läuft in einem abgeschotteten iframe. Sie spricht nur über `@gamehearth/sdk/client` mit der Plattform: `connect()`, `game.onUpdate(...)`, `game.move(zug)`. Kein `fetch`, kein WebSocket, keine Bilder oder Schriften von fremden Adressen; nur Dateien aus dem eigenen Build.
- Ein Update enthält den **Snapshot** dieses Spielers (`public`, `me` = eigener Bereich, `moves` = eigene erlaubte Züge, `result`) und `players` mit Namen. Was nicht im Snapshot steht, kennt die Oberfläche nicht; sie kann also nichts verraten.
- Schick nur Züge aus `snapshot.moves`. Der neue Stand kommt danach über `onUpdate`, nicht als Antwort von `move`.
- Verbindungsabbrüche und Fehler zeigt die Plattform selbst an.
- Grafik und Ton: am einfachsten mit Phaser zeichnen (wie im Beispiel). Eigene Dateien kommen nach `client/public/` und brauchen eine Lizenz CC0, CC-BY oder CC-BY-SA; keine Bilder aus dem Internet ohne klare Lizenz.
- Die Plattform ist für Handys zuerst gebaut. Teste in `dev` mit den schmalen Rahmen; alles muss mit Antippen gehen.
- Phaser 4, nicht Phaser 3: Beispiele aus dem Netz sind oft Phaser 3. Halte dich an die Muster in `client/src/scene.ts`; bei Fehlermeldungen zu unbekannten Methoden steckt meist Phaser-3-Code dahinter.

## Typische Fehler

| Meldung oder Symptom | Ursache und Abhilfe |
|---|---|
| `Math.random() ist in Spielen nicht erlaubt` | `random` aus `setup` oder `ctx.random` in `apply` benutzen |
| `beim ersten Durchlauf … beim Wiederholen …` | Zustand außerhalb der Funktionen oder nicht wiederholbarer Zufall |
| `… ist ein Set` oder `… ist kein JSON-Wert` | Arrays oder Objekte mit `true`-Werten nehmen |
| `nach apply kann niemand ziehen, aber result meldet kein Ende` | `result` muss in dieser Lage ein Ergebnis liefern, oder `legalMoves` vergisst Züge |
| Leck: Züge von p1 hängen von verdeckten Werten ab | ein Zug enthält etwas aus `secret` oder von anderen Spielern |
| Warnung: Wert steht gleichzeitig in `public` und bei einem Spieler | Aufdecken heißt verschieben, nicht kopieren |
| Warnung: erlaubter Zug ändert nichts | in `apply` fehlt ein Fall für diesen Zugtyp |
| Partie endet nie | `result` erkennt das Ende nicht, oder ein Zug bringt das Spiel nicht weiter |
| `liegt außerhalb des Spielordners` | nur Dateien aus diesem Ordner und `@gamehearth/sdk` importieren |
| Typfehler `Type 'string' is not assignable to type '"play"'` (oft mit langem Text zu `exactOptionalPropertyTypes`) | ein Zug als Objekt-Literal ohne Typ; `const action: MeinZug = { type: "play", … }` schreiben |
| Oberfläche bleibt leer, `dev` zeigt einen Fehler aus dem iframe | Fehlermeldung samt Datei und Zeile in der Ausgabe von `dev` lesen |
| In der Konsole des Browsers: `Unrecognized Content-Security-Policy directive 'webrtc'` | harmlos: Die Abschottung der Plattform verbietet WebRTC auch für Browser, die die Regel kennen; Chromium kennt sie noch nicht |

Jeder Fund von `check` nennt einen Befehl, mit dem sich genau diese Partie nachspielen lässt (`npx gamehearth check . --players 3 --seed check-3-17`). Damit siehst du alle Züge einzeln.

## Das Beispiel ersetzen

Wenn das eigene Spiel steht, darf vom Kartenduell nichts übrig bleiben:

- `manifest.json`: `name`, `description`, `players`, `roles` passend setzen. Die `id` kommt aus dem Ordnernamen. Passt sie nicht (etwa `mein-spiel` aus dem Starter-Repo), änder sie jetzt in `manifest.json` und `package.json`: nur Kleinbuchstaben, Ziffern und Bindestriche. Nach dem ersten Veröffentlichen ändert sie sich nie mehr.
- `package.json`: `description`.
- `src/`, `client/src/`, `test/`: Regeln, Oberfläche und Tests des eigenen Spiels. Die Dateinamen darfst du behalten oder ändern, nur `src/index.ts` muss das Spiel als `default` exportieren.
- `client/index.html`: Titel.
- `README.md`: Regeln des eigenen Spiels; den Hinweis „enthält noch das Beispiel“ oben entfernen.
- Zum Schluss nach Resten suchen: `Kartenduell`, `duel`, `Duel` in `src/`, `client/`, `test/`, `README.md`, `manifest.json` und `package.json`.
- Das ursprüngliche Beispiel liegt danach weiter zum Nachschlagen unter `node_modules/gamehearth/templates/rundenbasiert/`.
- `AGENTS.md` und `CLAUDE.md` bleiben, wie sie sind. Sie erwähnen das Kartenduell als Beispiel der Vorlage.

## Mehr Einzelheiten

Diese Dateien passen immer zur installierten Version. Lies sie, bevor du etwas benutzt, das hier nicht steht:

- `node_modules/@gamehearth/sdk/README.md`: der vollständige Vertrag für Regeln und Oberfläche, Fehler der Plattform, Grenzen der Server-Sandbox
- `node_modules/gamehearth/README.md`: `dev`, `check`, `pack` und Kataloge
- Ein größeres Beispiel mit verdeckten Karten, Sonderregeln und aufwendigerer Oberfläche: Mau-Mau, https://github.com/weilers-git/gamehearth-mau-mau

Ändere nichts in `node_modules` und schalte keine Prüfungen ab. Wenn der Vertrag etwas nicht hergibt, sag der Person, was nicht geht.

## Veröffentlichen

Vor dem ersten Release fragst du die Person:

- **Lizenz:** Vorbelegt sind MIT für den Code und CC0 für Grafik (siehe `LICENSE` und `manifest.json`). Erklär kurz: Jeder darf das Spiel dann benutzen, ändern und weitergeben. Andere erlaubte Lizenzen: jede OSI-Lizenz für Code, CC0, CC-BY oder CC-BY-SA für Grafik.
- **Name in der `LICENSE`:** wer als Urheber dasteht; das ist öffentlich sichtbar.

Ablauf:

1. Version in `manifest.json` und `package.json` erhöhen (`0.1.0` → `0.2.0`), committen.
2. Das Repo auf GitHub hochladen. Ein Tag startet die Release-CI: `git tag v0.2.0 && git push origin v0.2.0`. Sie baut mit `check` und `pack` das Spielpaket und hängt es an ein Release.
3. Damit ein Gamehearth-Server das Spiel installieren kann, braucht es einen **Katalog**: ein eigenes Repo mit einer `catalog.json`. Anlegen und eintragen mit `npx gamehearth catalog add catalog.json <adresse-des-pakets> --name "Mein Katalog"`. Auf dem Server fügt ein Admin unter „Verwaltung“ die Raw-Adresse der `catalog.json` hinzu und installiert das Spiel. Einzelheiten in `node_modules/gamehearth/README.md`.
