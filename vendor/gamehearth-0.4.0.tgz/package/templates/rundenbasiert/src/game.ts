import { defineGame, type GameState, type PlayerId } from "@gamehearth/sdk";

export const rounds = 5;
export const handSize = 3;
export const deckSize = 30;

export type Card = number;

export interface Reveal {
  cards: Record<PlayerId, Card>;
  winners: PlayerId[];
}

export interface Public {
  round: number;
  scores: Record<PlayerId, number>;
  played: Record<PlayerId, boolean>;
  lastReveal: Reveal | null;
  deckSize: number;
  finished: boolean;
}

export interface Hand {
  cards: Card[];
  chosen: Card | null;
}

export interface Secret {
  deck: Card[];
}

export type DuelState = GameState<Public, Hand, Secret>;

export type DuelAction = { type: "play"; card: Card };

export function fullDeck(): Card[] {
  return Array.from({ length: deckSize }, (_, index) => index + 1);
}

export const duel = defineGame<DuelState, DuelAction>({
  setup({ players, random }) {
    const deck = random.shuffle(fullDeck());
    const hands: Record<PlayerId, Hand> = {};
    const scores: Record<PlayerId, number> = {};
    const played: Record<PlayerId, boolean> = {};
    for (const player of players) {
      hands[player] = { cards: deck.splice(0, handSize), chosen: null };
      scores[player] = 0;
      played[player] = false;
    }
    return {
      public: { round: 1, scores, played, lastReveal: null, deckSize: deck.length, finished: false },
      players: hands,
      secret: { deck },
    };
  },

  legalMoves(state, player) {
    const hand = state.players[player];
    if (state.public.finished || hand === undefined || hand.chosen !== null) {
      return [];
    }
    return hand.cards.map((card) => ({ type: "play", card }));
  },

  apply(state, action, { player, players }) {
    const hand = state.players[player]!;
    hand.cards = hand.cards.filter((card) => card !== action.card);
    hand.chosen = action.card;
    state.public.played[player] = true;

    if (!players.every((seat) => state.public.played[seat])) {
      return;
    }

    const cards: Record<PlayerId, Card> = {};
    for (const seat of players) {
      cards[seat] = state.players[seat]!.chosen!;
    }
    const best = Math.max(...Object.values(cards));
    const winners = players.filter((seat) => cards[seat] === best);
    for (const seat of winners) {
      state.public.scores[seat] = (state.public.scores[seat] ?? 0) + 1;
    }
    state.public.lastReveal = { cards, winners };

    for (const seat of players) {
      state.players[seat]!.chosen = null;
      state.public.played[seat] = false;
    }

    if (state.public.round === rounds) {
      state.public.finished = true;
      return;
    }
    for (const seat of players) {
      const card = state.secret.deck.pop();
      if (card !== undefined) {
        state.players[seat]!.cards.push(card);
      }
    }
    state.public.deckSize = state.secret.deck.length;
    state.public.round += 1;
  },

  result(state) {
    if (!state.public.finished) {
      return undefined;
    }
    const scores = Object.entries(state.public.scores);
    const best = Math.max(...scores.map(([, score]) => score));
    return { winners: scores.filter(([, score]) => score === best).map(([player]) => player) };
  },
});
