export { duel as default, deckSize, duel, fullDeck, handSize, rounds } from "./game";
export type { Card, DuelAction, DuelState, Hand, Public, Reveal, Secret } from "./game";
