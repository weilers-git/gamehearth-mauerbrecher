import { applyMove, createMatch, playerSnapshot, type Match } from "@gamehearth/sdk/platform";
import { describe, expect, it } from "vitest";
import { deckSize, duel, fullDeck, handSize, rounds, type DuelAction, type DuelState } from "../src";

type DuelMatch = Match<DuelState, DuelAction>;

function start(playerCount: number, seed = "test"): DuelMatch {
  const created = createMatch(duel, { playerCount, seed });
  if (!created.ok) {
    throw new Error(created.error.message);
  }
  return created.match;
}

function play(match: DuelMatch, player: string, card: number): DuelMatch {
  const action: DuelAction = { type: "play", card };
  const outcome = applyMove(duel, match, { player, action, now: 0 });
  if (!outcome.ok) {
    throw new Error(`${player} legt ${card}: ${outcome.error.code} ${outcome.error.message}`);
  }
  return outcome.match;
}

function firstCard(match: DuelMatch, player: string): number {
  const card = match.state.players[player]?.cards[0];
  if (card === undefined) {
    throw new Error(`${player} hat keine Karte`);
  }
  return card;
}

function everyCard(match: DuelMatch): number[] {
  const { state } = match;
  const inHands = match.players.flatMap((player) => {
    const hand = state.players[player];
    return hand === undefined ? [] : [...hand.cards, ...(hand.chosen === null ? [] : [hand.chosen])];
  });
  const revealed = state.public.lastReveal === null ? [] : Object.values(state.public.lastReveal.cards);
  return [...inHands, ...state.secret.deck, ...revealed];
}

describe("Kartenduell", () => {
  it("teilt jedem drei Karten aus, der Rest bleibt geheim im Stapel", () => {
    const match = start(3);
    for (const player of match.players) {
      expect(match.state.players[player]?.cards).toHaveLength(handSize);
    }
    expect(match.state.secret.deck).toHaveLength(deckSize - 3 * handSize);
    expect(match.state.public.deckSize).toBe(match.state.secret.deck.length);
    expect(everyCard(match).sort((a, b) => a - b)).toEqual(fullDeck());
  });

  it("lässt alle gleichzeitig wählen und zeigt die Wahl erst, wenn alle gelegt haben", () => {
    let match = start(2);
    expect(match.moves["p1"]).toHaveLength(handSize);
    expect(match.moves["p2"]).toHaveLength(handSize);

    const card = firstCard(match, "p1");
    match = play(match, "p1", card);
    expect(match.moves["p1"]).toEqual([]);
    expect(match.state.public.played["p1"]).toBe(true);
    expect(JSON.stringify(playerSnapshot(match, "p2"))).not.toContain(`"chosen":${card}`);

    match = play(match, "p2", firstCard(match, "p2"));
    expect(match.state.public.lastReveal?.cards["p1"]).toBe(card);
    expect(match.state.public.round).toBe(2);
    expect(match.state.public.played).toEqual({ p1: false, p2: false });
  });

  it("gibt der höchsten Karte den Punkt und lässt alle nachziehen", () => {
    let match = start(2, "punkt");
    const p1 = firstCard(match, "p1");
    const p2 = firstCard(match, "p2");
    match = play(match, "p1", p1);
    match = play(match, "p2", p2);
    const winner = p1 > p2 ? "p1" : "p2";
    expect(match.state.public.lastReveal?.winners).toEqual([winner]);
    expect(match.state.public.scores[winner]).toBe(1);
    expect(match.state.players["p1"]?.cards).toHaveLength(handSize);
    expect(match.state.public.deckSize).toBe(deckSize - 2 * handSize - 2);
  });

  it(`endet nach ${rounds} Runden, und wer die meisten Punkte hat, gewinnt`, () => {
    let match = start(4, "ende");
    for (let round = 1; round <= rounds; round++) {
      for (const player of match.players) {
        match = play(match, player, firstCard(match, player));
      }
    }
    expect(match.state.public.finished).toBe(true);
    const scores = match.state.public.scores;
    const best = Math.max(...Object.values(scores));
    expect(match.result?.winners).toEqual(match.players.filter((player) => scores[player] === best));
    for (const player of match.players) {
      expect(match.moves[player]).toEqual([]);
    }
  });
});
