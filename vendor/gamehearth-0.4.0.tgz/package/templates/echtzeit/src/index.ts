export {
  catcherSpeed,
  clamp,
  directions,
  fieldHeight,
  fieldWidth,
  freezeTicks,
  radius,
  roundTicks,
  runnerSpeed,
  startPoint,
  tag as default,
  tag,
  tagBackTicks,
  touching,
} from "./game";
export type { Direction, Point, Public, TagAction, TagState } from "./game";
