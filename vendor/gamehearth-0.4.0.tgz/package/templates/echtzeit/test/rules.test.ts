import { createMatch, stepMatch, tickMs, type Match } from "@gamehearth/sdk/platform";
import { describe, expect, it } from "vitest";
import tag, { catcherSpeed, fieldWidth, freezeTicks, radius, roundTicks, runnerSpeed, startPoint, tagBackTicks, type TagAction, type TagState } from "../src/index";

type TagMatch = Match<TagState, TagAction>;

function start(players = 2, seed = "fangen"): TagMatch {
  const created = createMatch(tag, { playerCount: players, seed });
  if (!created.ok) {
    throw new Error(created.error.message);
  }
  return created.match;
}

function step(match: TagMatch, inputs: { player: string; action: TagAction }[] = [], times = 1): TagMatch {
  let current = match;
  for (let i = 0; i < times; i++) {
    const outcome = stepMatch(tag, current, { inputs: i === 0 ? inputs : [], now: 0, dt: tickMs });
    if (!outcome.ok) {
      throw new Error(outcome.error.message);
    }
    current = outcome.match;
  }
  return current;
}

function steer(player: string, dir: TagAction["dir"]) {
  return { player, action: { type: "steer", dir } as TagAction };
}

function placed(match: TagMatch, changes: (state: TagState) => void): TagMatch {
  const copy = JSON.parse(JSON.stringify(match)) as TagMatch;
  changes(copy.state);
  return copy;
}

describe("Fangen", () => {
  it("stellt alle verteilt auf, lost einen Fänger aus und gibt ihm einen kurzen Vorsprung für die anderen", () => {
    const match = start(3);
    expect(Object.keys(match.state.public.pos)).toEqual(["p1", "p2", "p3"]);
    expect(match.state.public.pos["p1"]).toEqual(startPoint(0, 3));
    expect(match.players).toContain(match.state.public.catcher);
    expect(match.state.public.frozen).toBe(freezeTicks);
    expect(match.state.public.ticksLeft).toBe(roundTicks);
  });

  it("lost bei verschiedenen Seeds verschiedene Fänger aus", () => {
    const catchers = new Set(Array.from({ length: 20 }, (_, index) => start(4, `seed-${index}`).state.public.catcher));
    expect(catchers.size).toBeGreaterThan(1);
  });

  it("bewegt Läufer in die gehaltene Richtung und hält sie im Feld", () => {
    let match = placed(start(2), (state) => {
      state.public.catcher = "p1";
      state.public.pos["p2"] = { x: fieldWidth - radius - 2, y: 100 };
    });
    match = step(match, [steer("p2", "right")]);
    expect(match.state.public.pos["p2"]).toEqual({ x: fieldWidth - radius, y: 100 });
    match = step(match, [steer("p2", "up")], 2);
    expect(match.state.public.pos["p2"]).toEqual({ x: fieldWidth - radius, y: 100 - 2 * runnerSpeed });
  });

  it("lässt den Fänger erst nach dem Vorsprung los und dann schneller laufen", () => {
    let match = placed(start(2), (state) => {
      state.public.catcher = "p1";
      state.public.pos["p1"] = { x: 50, y: 50 };
      state.public.pos["p2"] = { x: 300, y: 200 };
    });
    match = step(match, [steer("p1", "right")], freezeTicks);
    expect(match.state.public.pos["p1"]).toEqual({ x: 50, y: 50 });
    match = step(match, [], 1);
    expect(match.state.public.pos["p1"]).toEqual({ x: 50 + catcherSpeed, y: 50 });
  });

  it("macht den Berührten zum Fänger, friert ihn kurz ein und schützt den alten vor sofortigem Zurückfangen", () => {
    let match = placed(start(2), (state) => {
      state.public.catcher = "p1";
      state.public.frozen = 0;
      state.public.pos["p1"] = { x: 100, y: 100 };
      state.public.pos["p2"] = { x: 100 + 2 * radius + 3, y: 100 };
    });
    match = step(match, [steer("p1", "right")]);
    expect(match.state.public).toMatchObject({ catcher: "p2", frozen: freezeTicks, tagBack: "p1", tagBackLeft: tagBackTicks });
    match = step(match, [steer("p1", "none")], tagBackTicks - 1);
    expect(match.state.public.catcher).toBe("p2");
    match = step(match, [], 1);
    expect(match.state.public).toMatchObject({ catcher: "p1", tagBack: "p2" });
  });

  it("zählt die Zeit als Fänger und lässt nach 60 Sekunden den mit der kürzesten Zeit gewinnen", () => {
    let match = placed(start(3), (state) => {
      state.public.catcher = "p2";
      state.public.ticksLeft = 3;
      state.public.caught = { p1: 0, p2: 10, p3: 0 };
    });
    match = step(match, [], 3);
    expect(match.state.public.caught).toEqual({ p1: 0, p2: 13, p3: 0 });
    expect(match.result).toEqual({ winners: ["p1", "p3"] });
  });

  it("nimmt nach dem Ende keine Eingaben mehr an", () => {
    const match = placed(start(2), (state) => {
      state.public.ticksLeft = 1;
    });
    const ended = step(match, [], 1);
    expect(ended.moves).toEqual({ p1: [], p2: [] });
  });
});
