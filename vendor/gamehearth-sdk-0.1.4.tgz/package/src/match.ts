import type { GameDefinition, GameResult } from "./game";
import { canonicalJson, cloneJson, deepFreeze, findNonJson } from "./json";
import { optionsProblem, type GameOptions, type OptionsShape } from "./options";
import type { AnyCatalog, CatalogIds, CatalogInput, ProfileChange, Profiles } from "./profile";
import { ProfileSession, forbiddenWriter } from "./profile-session";
import { SeededRandom, randomStateFromSeed, type RandomState } from "./random";
import { describeStateProblem, seatIds, type AnyGameState, type PlayerId } from "./state";

export const matchFormat = 1;
export const maxActionLength = 16_384;
export const maxActionDepth = 32;
export const tickRate = 20;
export const tickMs = 1000 / tickRate;

export interface Match<S extends AnyGameState, A> {
  format: typeof matchFormat;
  seed: string;
  players: PlayerId[];
  options?: GameOptions;
  state: S;
  moves: Record<PlayerId, A[]>;
  randomState: RandomState;
  version: number;
  tick?: number;
  result?: GameResult;
}

export interface ProfileInput {
  catalog?: CatalogInput;
  profiles?: Readonly<Record<PlayerId, unknown>>;
}

export interface CreateMatchOptions<O extends OptionsShape<O> = GameOptions> extends ProfileInput {
  playerCount: number;
  seed: string;
  options?: O;
}

export interface Move<A> {
  player: PlayerId;
  action: A;
  now: number;
  expectedVersion?: number;
}

export type MatchErrorCode = "game-over" | "unknown-player" | "stale" | "not-your-turn" | "illegal-move" | "missing-item" | "game-error";

export type GamePhase = "setup" | "legalMoves" | "apply" | "result" | "tick";

export interface StepInput<A> {
  player: PlayerId;
  action: A;
}

export interface Step<A> {
  inputs: readonly StepInput<A>[];
  now: number;
  dt: number;
}

export type InputResult = { ok: true } | { ok: false; code: MatchErrorCode; message: string };

export type StepOutcome<S extends AnyGameState, A> =
  | { ok: true; match: Match<S, A>; results: InputResult[]; changes?: ProfileChange[] }
  | { ok: false; error: MatchError };

export interface MatchError {
  code: MatchErrorCode;
  message: string;
  phase?: GamePhase;
  player?: PlayerId;
  stack?: string;
}

export type MatchOutcome<S extends AnyGameState, A> =
  | { ok: true; match: Match<S, A>; changes?: ProfileChange[] }
  | { ok: false; error: MatchError };

type Failure = { ok: false; error: MatchError };
type Attempt<T> = { ok: true; value: T } | Failure;

interface Draft {
  seed: string;
  players: PlayerId[];
  options?: GameOptions;
  state: unknown;
  randomState: RandomState;
  version: number;
  tick?: number;
  actor?: PlayerId;
}

export function createMatch<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  options: CreateMatchOptions<NoInfer<O>>,
): MatchOutcome<S, A> {
  if (!Number.isSafeInteger(options.playerCount) || options.playerCount < 1) {
    throw new RangeError(`playerCount muss eine ganze Zahl ab 1 sein, bekam ${options.playerCount}`);
  }
  if (typeof options.seed !== "string" || options.seed.length === 0) {
    throw new TypeError("seed muss ein nicht leerer String sein");
  }
  if (options.options !== undefined) {
    const problem = optionsProblem(options.options);
    if (problem !== undefined) {
      throw new TypeError(problem);
    }
  }
  const chosen = options.options === undefined || Object.keys(options.options).length === 0 ? undefined : (cloneJson(options.options) as GameOptions);
  const players = seatIds(options.playerCount);
  const random = new SeededRandom(randomStateFromSeed(options.seed));
  const profiles = new ProfileSession(players, options.catalog, options.profiles).snapshot() as Profiles<C>;
  const setup = runGameCode("setup", undefined, () =>
    game.setup(withForbiddenWriter({ players: [...players], random, options: readOptions<O>(chosen), profiles }, "setup")),
  );
  if (!setup.ok) {
    return setup;
  }
  return settle(game, "setup", profiles, {
    seed: options.seed,
    players,
    ...withOptions(chosen),
    state: setup.value,
    randomState: random.state,
    version: 0,
    ...(isRealtime(game) ? { tick: 0 } : {}),
  });
}

export function applyMove<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  match: Match<S, A>,
  move: Move<A>,
  profiles: ProfileInput = {},
): MatchOutcome<S, A> {
  if (match.format !== matchFormat) {
    throw new Error(`Unbekanntes Partie-Format ${String(match.format)}, erwartet ${matchFormat}`);
  }
  if (typeof move.now !== "number" || !Number.isFinite(move.now)) {
    throw new RangeError(`now muss ein Zeitpunkt in Millisekunden sein, bekam ${String(move.now)}`);
  }
  const checked = checkMove(match, move);
  if (!checked.ok) {
    return checked;
  }
  const session = new ProfileSession(match.players, profiles.catalog, profiles.profiles);
  const applied = applyChecked(game, match, move.player, checked.action, move.now, match.version + 1, session);
  return applied.ok ? withChanges(applied.match, session.changes) : applied;
}

export function refreshMatch<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  match: Match<S, A>,
  profiles: ProfileInput = {},
): MatchOutcome<S, A> {
  if (match.format !== matchFormat) {
    throw new Error(`Unbekanntes Partie-Format ${String(match.format)}, erwartet ${matchFormat}`);
  }
  if (match.result !== undefined) {
    throw new Error("Die Partie ist schon beendet, ihre Züge lassen sich nicht neu berechnen");
  }
  if (match.tick !== undefined) {
    throw new Error("Echtzeit-Partien berechnen ihre Züge mit jedem Tick neu und brauchen kein refreshMatch");
  }
  const session = new ProfileSession(match.players, profiles.catalog, profiles.profiles);
  return settle(game, "refresh", session.snapshot() as Profiles<C>, {
    seed: match.seed,
    players: [...match.players],
    ...withOptions(match.options),
    state: cloneJson(match.state),
    randomState: match.randomState,
    version: match.version + 1,
  });
}

export function stepMatch<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  match: Match<S, A>,
  step: Step<A>,
  profiles: ProfileInput = {},
): StepOutcome<S, A> {
  if (match.format !== matchFormat) {
    throw new Error(`Unbekanntes Partie-Format ${String(match.format)}, erwartet ${matchFormat}`);
  }
  const tick = game.tick;
  if (match.tick === undefined || typeof tick !== "function") {
    throw new Error("stepMatch gibt es nur für Echtzeit-Partien eines Spiels mit tick");
  }
  if (match.result !== undefined) {
    throw new Error("Die Partie ist schon beendet, es gibt keinen weiteren Tick");
  }
  if (typeof step.now !== "number" || !Number.isFinite(step.now)) {
    throw new RangeError(`now muss ein Zeitpunkt in Millisekunden sein, bekam ${String(step.now)}`);
  }
  if (typeof step.dt !== "number" || !Number.isFinite(step.dt) || step.dt <= 0) {
    throw new RangeError(`dt muss eine positive Zahl von Millisekunden sein, bekam ${String(step.dt)}`);
  }
  let current = match;
  let session = new ProfileSession(match.players, profiles.catalog, profiles.profiles);
  const changes: ProfileChange[] = [];
  const results: InputResult[] = [];
  for (const input of step.inputs) {
    const checked = checkMove(current, { player: input.player, action: input.action, now: step.now });
    if (!checked.ok) {
      results.push({ ok: false, code: checked.error.code, message: checked.error.message });
      continue;
    }
    const attempt = session.fork();
    const applied = applyChecked(game, current, input.player, checked.action, step.now, match.version, attempt);
    if (!applied.ok && applied.error.code === "missing-item") {
      results.push({ ok: false, code: applied.error.code, message: applied.error.message });
      continue;
    }
    if (!applied.ok) {
      return applied;
    }
    current = applied.match;
    session = attempt;
    changes.push(...attempt.changes);
    results.push({ ok: true });
  }
  const version = match.version + 1;
  const ticks = match.tick + 1;
  if (current.result !== undefined) {
    return stepResult({ ...current, version, tick: ticks }, results, changes);
  }
  const random = new SeededRandom(current.randomState);
  const draft = cloneJson(current.state);
  const ticking = session.fork();
  const ticked = runGameCode("tick", undefined, () =>
    tick.call(game, draft, step.dt, {
      players: [...current.players],
      random,
      options: readOptions<O>(current.options),
      now: step.now,
      profiles: ticking.live() as Profiles<C>,
      profile: ticking.writer("tick"),
    }),
  );
  const tickFailure = profileFailure(ticking, "tick", undefined);
  if (tickFailure !== undefined) {
    return tickFailure;
  }
  if (!ticked.ok) {
    return ticked;
  }
  changes.push(...ticking.changes);
  const settled = settle(game, "tick", ticking.snapshot() as Profiles<C>, {
    seed: current.seed,
    players: [...current.players],
    ...withOptions(current.options),
    state: ticked.value === undefined ? draft : ticked.value,
    randomState: random.state,
    version,
    tick: ticks,
  });
  return settled.ok ? stepResult(settled.match, results, changes) : settled;
}

function stepResult<S extends AnyGameState, A>(match: Match<S, A>, results: InputResult[], changes: ProfileChange[]): StepOutcome<S, A> {
  return changes.length === 0 ? { ok: true, match, results } : { ok: true, match, results, changes: [...changes] };
}

function withChanges<S extends AnyGameState, A>(match: Match<S, A>, changes: ProfileChange[]): MatchOutcome<S, A> {
  return changes.length === 0 ? { ok: true, match } : { ok: true, match, changes: [...changes] };
}

function withForbiddenWriter<T extends object>(context: T, where: string): T {
  Object.defineProperty(context, "profile", { value: forbiddenWriter(where), enumerable: false });
  return context;
}

function profileFailure(session: ProfileSession, phase: "apply" | "tick", player: PlayerId | undefined): Failure | undefined {
  const failed = session.failure;
  if (failed === undefined) {
    return undefined;
  }
  if (failed.kind === "missing") {
    return failure("missing-item", failed.message);
  }
  return gameError(phase, player, failed.message, failed.stack);
}

function applyChecked<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  match: Match<S, A>,
  player: PlayerId,
  chosen: A,
  now: number,
  version: number,
  session: ProfileSession,
): MatchOutcome<S, A> {
  const random = new SeededRandom(match.randomState);
  const draft = cloneJson(match.state);
  const applied = runGameCode("apply", player, () =>
    game.apply(draft, cloneJson(chosen), {
      players: [...match.players],
      random,
      options: readOptions<O>(match.options),
      player,
      now,
      profiles: session.live() as Profiles<C>,
      profile: session.writer("apply"),
    }),
  );
  const failed = profileFailure(session, "apply", player);
  if (failed !== undefined) {
    return failed;
  }
  if (!applied.ok) {
    return applied;
  }
  return settle(game, "apply", session.snapshot() as Profiles<C>, {
    seed: match.seed,
    players: [...match.players],
    ...withOptions(match.options),
    state: applied.value === undefined ? draft : applied.value,
    randomState: random.state,
    version,
    ...(match.tick === undefined ? {} : { tick: match.tick }),
    actor: player,
  });
}

function isRealtime(game: { tick?: unknown }): boolean {
  return typeof game.tick === "function";
}

function readOptions<O>(options: GameOptions | undefined): O {
  return deepFreeze(cloneJson(options ?? {})) as O;
}

function withOptions(options: GameOptions | undefined): { options?: GameOptions } {
  return options === undefined ? {} : { options: cloneJson(options) };
}

export function checkMove<S extends AnyGameState, A>(
  match: Match<S, A>,
  move: Move<A>,
): { ok: true; action: A } | { ok: false; error: MatchError } {
  if (match.result !== undefined) {
    return failure("game-over", "die Partie ist bereits beendet");
  }
  if (!match.players.includes(move.player)) {
    return failure("unknown-player", `${String(move.player)} ist kein Sitz dieser Partie`);
  }
  if (move.expectedVersion !== undefined && move.expectedVersion !== match.version) {
    return failure(
      "stale",
      `der Zug bezieht sich auf Stand ${move.expectedVersion}, die Partie ist schon bei Stand ${match.version}`,
    );
  }
  const available = match.moves[move.player] ?? [];
  if (available.length === 0) {
    return failure("not-your-turn", `${move.player} kann gerade nicht ziehen`);
  }
  const wanted = canonicalAction(move.action);
  if (!wanted.ok) {
    return wanted;
  }
  const chosen = available.find((candidate) => canonicalJson(candidate) === wanted.value);
  if (chosen === undefined) {
    return failure("illegal-move", `dieser Zug ist für ${move.player} gerade nicht erlaubt`);
  }
  return { ok: true, action: chosen };
}

function canonicalAction(action: unknown): Attempt<string> {
  let serialized: string | undefined;
  try {
    serialized = JSON.stringify(action);
  } catch {
    return failure("illegal-move", "der Zug ist kein gültiger JSON-Wert");
  }
  if (serialized === undefined) {
    return failure("illegal-move", "der Zug fehlt");
  }
  if (serialized.length > maxActionLength) {
    return failure("illegal-move", `der Zug ist größer als ${maxActionLength} Zeichen`);
  }
  const problem = findNonJson(action, "action", maxActionDepth);
  if (problem !== undefined) {
    return failure("illegal-move", `${problem.path} ${problem.reason}`);
  }
  return { ok: true, value: canonicalJson(action) };
}

type SettlePhase = "setup" | "apply" | "tick" | "refresh";

function gamePhase(phase: SettlePhase): GamePhase {
  return phase === "refresh" ? "legalMoves" : phase;
}

function settle<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  phase: SettlePhase,
  profiles: Profiles<C>,
  draft: Draft,
): MatchOutcome<S, A> {
  try {
    return settleUnguarded(game, phase, profiles, draft);
  } catch (error) {
    return gameError(
      gamePhase(phase),
      draft.actor,
      `nach ${phase} ist ein unerwarteter Fehler aufgetreten: ${errorMessage(error)}`,
      errorStack(error),
    );
  }
}

function settleUnguarded<S extends AnyGameState, A, O extends OptionsShape<O> = GameOptions, C extends CatalogIds = AnyCatalog>(
  game: GameDefinition<S, A, O, C>,
  phase: SettlePhase,
  profiles: Profiles<C>,
  draft: Draft,
): MatchOutcome<S, A> {
  const stateProblem = describeStateProblem(draft.state, draft.players);
  if (stateProblem !== undefined) {
    return gameError(gamePhase(phase), draft.actor, `${phase} hat einen ungültigen Zustand geliefert: ${stateProblem}`);
  }
  const state = cloneJson(draft.state) as S;
  const readOnly = deepFreeze(cloneJson(state));
  const base = {
    format: matchFormat,
    seed: draft.seed,
    players: draft.players,
    ...withOptions(draft.options),
    state,
    randomState: draft.randomState,
    version: draft.version,
    ...(draft.tick === undefined ? {} : { tick: draft.tick }),
  } as const;

  const result = runGameCode("result", undefined, () => game.result(readOnly));
  if (!result.ok) {
    return result;
  }
  if (result.value !== undefined && result.value !== null) {
    const resultProblem = describeResultProblem(result.value, draft.players);
    if (resultProblem !== undefined) {
      return gameError("result", undefined, `result hat ein ungültiges Ergebnis geliefert: ${resultProblem}`);
    }
    const moves = Object.fromEntries(draft.players.map((player) => [player, [] as A[]]));
    return { ok: true, match: { ...base, moves, result: { winners: [...result.value.winners] } } };
  }

  const moves: Record<PlayerId, A[]> = {};
  const context = deepFreeze(withForbiddenWriter({ players: [...draft.players], options: readOptions<O>(draft.options), profiles }, "legalMoves"));
  for (const player of draft.players) {
    const legal = runGameCode("legalMoves", player, () => game.legalMoves(readOnly, player, context));
    if (!legal.ok) {
      return legal;
    }
    if (!Array.isArray(legal.value)) {
      return gameError("legalMoves", player, `legalMoves für ${player} muss ein Array liefern`);
    }
    const problem = findNonJson(legal.value, `legalMoves(${player})`, maxActionDepth);
    if (problem !== undefined) {
      return gameError("legalMoves", player, `${problem.path} ${problem.reason}`);
    }
    const tooLarge = legal.value.findIndex((candidate) => JSON.stringify(candidate).length > maxActionLength);
    if (tooLarge !== -1) {
      return gameError(
        "legalMoves",
        player,
        `legalMoves(${player})[${tooLarge}] ist größer als ${maxActionLength} Zeichen und könnte nie gesendet werden`,
      );
    }
    moves[player] = cloneJson(legal.value);
  }
  if (draft.tick === undefined && draft.players.every((player) => (moves[player] ?? []).length === 0)) {
    return gameError(
      gamePhase(phase),
      draft.actor,
      phase === "refresh"
        ? "mit den geänderten Profilen kann niemand mehr ziehen, aber result meldet kein Ende; die Partie würde für immer hängen"
        : `nach ${phase} kann niemand ziehen, aber result meldet kein Ende; die Partie würde für immer hängen`,
    );
  }
  return { ok: true, match: { ...base, moves } };
}

function describeResultProblem(result: unknown, players: readonly PlayerId[]): string | undefined {
  if (typeof result !== "object" || result === null || !Array.isArray((result as GameResult).winners)) {
    return "erwartet wird ein Objekt der Form { winners: [...] }";
  }
  const winners = (result as GameResult).winners;
  for (const winner of winners) {
    if (typeof winner !== "string" || !players.includes(winner)) {
      return `winners enthält ${JSON.stringify(winner)}, das ist kein Sitz dieser Partie (Sitze: ${players.join(", ")})`;
    }
  }
  if (new Set(winners).size !== winners.length) {
    return "winners enthält einen Sitz mehrfach";
  }
  return undefined;
}

function runGameCode<T>(phase: GamePhase, player: PlayerId | undefined, run: () => T): Attempt<T> {
  const label = phase === "legalMoves" && player !== undefined ? `legalMoves für ${player}` : phase;
  try {
    const value = run();
    if (isThenable(value)) {
      Promise.resolve(value).catch(() => undefined);
      return gameError(phase, player, `${label} darf nicht async sein und kein Promise zurückgeben`);
    }
    return { ok: true, value };
  } catch (error) {
    return gameError(phase, player, `${label} hat einen Fehler geworfen: ${errorMessage(error)}`, errorStack(error));
  }
}

function isThenable(value: unknown): value is PromiseLike<unknown> {
  return (
    value !== null &&
    (typeof value === "object" || typeof value === "function") &&
    typeof (value as { then?: unknown }).then === "function"
  );
}

function errorMessage(error: unknown): string {
  try {
    return error instanceof Error ? error.message : String(error);
  } catch {
    return "unbekannter Fehler";
  }
}

function errorStack(error: unknown): string | undefined {
  try {
    if (error instanceof Error && typeof error.stack === "string") {
      return error.stack.split("\n").slice(0, 8).join("\n");
    }
  } catch {
    return undefined;
  }
  return undefined;
}

function gameError(phase: GamePhase, player: PlayerId | undefined, message: string, stack?: string): Failure {
  const error: MatchError = { code: "game-error", message, phase };
  if (player !== undefined) {
    error.player = player;
  }
  if (stack !== undefined) {
    error.stack = stack;
  }
  return { ok: false, error };
}

function failure(code: MatchErrorCode, message: string): Failure {
  return { ok: false, error: { code, message } };
}
