export type OptionValue = string | number | boolean;

export type GameOptions = Readonly<Record<string, OptionValue>>;

export type OptionsShape<O> = { readonly [K in keyof O]: OptionValue };

export interface BooleanOptionSpec {
  label: string;
  type: "boolean";
  default: boolean;
}

export interface OptionChoice {
  value: string | number;
  label: string;
}

export interface ChoiceOptionSpec {
  label: string;
  type: "choice";
  default: string | number;
  choices: OptionChoice[];
}

export type OptionSpec = BooleanOptionSpec | ChoiceOptionSpec;

export type OptionsSpec = Record<string, OptionSpec>;

export const optionNamePattern = /^[a-z][a-zA-Z0-9]{0,39}$/;
export const maxOptions = 12;
export const maxOptionChoices = 20;
export const maxOptionLabelLength = 40;
export const maxOptionTextLength = 40;

export function validateOptionsSpec(spec: unknown): string[] {
  if (!isRecord(spec)) {
    return ['options muss ein Objekt wie { "stapeln": { "label": "7er stapeln", "type": "boolean", "default": true } } sein'];
  }
  const problems: string[] = [];
  const names = Object.keys(spec);
  if (names.length === 0) {
    problems.push("options darf nicht leer sein, ohne Optionen das Feld weglassen");
  }
  if (names.length > maxOptions) {
    problems.push(`options hat ${names.length} Einträge, erlaubt sind höchstens ${maxOptions}`);
  }
  for (const name of names) {
    if (name in Object.prototype) {
      problems.push(`options.${name}: dieser Name ist in JavaScript schon vergeben, nimm einen anderen`);
      continue;
    }
    if (!optionNamePattern.test(name)) {
      problems.push(
        `options.${name}: Namen beginnen mit einem Kleinbuchstaben, bestehen aus Buchstaben und Ziffern (ohne Bindestrich, damit ctx.options.${name.replace(/[^a-zA-Z0-9]/g, "")} geht) und haben höchstens 40 Zeichen, z. B. "spielzeit" oder "bubeAufBube"`,
      );
      continue;
    }
    problems.push(...optionProblems(name, spec[name]));
  }
  return problems;
}

function optionProblems(name: string, option: unknown): string[] {
  const where = `options.${name}`;
  if (!isRecord(option)) {
    return [`${where} muss ein Objekt mit label, type und default sein`];
  }
  const problems: string[] = [];
  const type = option["type"];
  const allowed = type === "choice" ? ["label", "type", "default", "choices"] : ["label", "type", "default"];
  for (const key of Object.keys(option)) {
    if (!allowed.includes(key)) {
      problems.push(`${where}.${key} ist unbekannt, erlaubt sind ${allowed.join(", ")}`);
    }
  }
  if (!isLabel(option["label"])) {
    problems.push(`${where}.label muss ein Anzeigename mit 1 bis ${maxOptionLabelLength} Zeichen sein`);
  }
  if (type === "boolean") {
    if (typeof option["default"] !== "boolean") {
      problems.push(`${where}.default muss bei type "boolean" true oder false sein`);
    }
    return problems;
  }
  if (type !== "choice") {
    problems.push(`${where}.type muss "boolean" (Ja/Nein) oder "choice" (Auswahl) sein`);
    return problems;
  }
  const choices = option["choices"];
  if (!Array.isArray(choices) || choices.length < 2 || choices.length > maxOptionChoices) {
    problems.push(`${where}.choices muss eine Liste mit 2 bis ${maxOptionChoices} Einträgen wie { "value": 60, "label": "1 Minute" } sein`);
    return problems;
  }
  const values: (string | number)[] = [];
  choices.forEach((choice, index) => {
    const at = `${where}.choices[${index}]`;
    if (!isRecord(choice)) {
      problems.push(`${at} muss ein Objekt wie { "value": 60, "label": "1 Minute" } sein`);
      return;
    }
    for (const key of Object.keys(choice)) {
      if (key !== "value" && key !== "label") {
        problems.push(`${at}.${key} ist unbekannt, erlaubt sind value und label`);
      }
    }
    const value = choice["value"];
    if (typeof value === "number" ? !Number.isSafeInteger(value) : !isText(value)) {
      problems.push(`${at}.value muss eine ganze Zahl oder ein Text mit 1 bis ${maxOptionTextLength} Zeichen sein`);
    } else if (values.includes(value as string | number)) {
      problems.push(`${at}.value ${JSON.stringify(value)} kommt mehrfach vor`);
    } else {
      values.push(value as string | number);
    }
    if (!isLabel(choice["label"])) {
      problems.push(`${at}.label muss ein Anzeigename mit 1 bis ${maxOptionLabelLength} Zeichen sein`);
    }
  });
  if (new Set(values.map((value) => typeof value)).size > 1) {
    problems.push(`${where}.choices mischt Zahlen und Texte; alle Werte einer Auswahl haben denselben Typ`);
  }
  if (!values.includes(option["default"] as string | number)) {
    problems.push(`${where}.default muss einer der Werte aus choices sein`);
  }
  return problems;
}

export function defaultOptions(spec: OptionsSpec | undefined): GameOptions {
  return resolveOptions(spec, undefined);
}

export function resolveOptions(spec: OptionsSpec | undefined, chosen: unknown): GameOptions {
  const resolved: Record<string, OptionValue> = {};
  if (spec === undefined) {
    return resolved;
  }
  const wanted = isRecord(chosen) ? chosen : {};
  for (const [name, option] of Object.entries(spec)) {
    const value = Object.hasOwn(wanted, name) ? wanted[name] : undefined;
    resolved[name] = isAllowedValue(option, value) ? value : option.default;
  }
  return resolved;
}

export function optionValueProblem(spec: OptionsSpec | undefined, name: string, value: unknown): string | undefined {
  const option = spec !== undefined && Object.hasOwn(spec, name) ? spec[name] : undefined;
  if (option === undefined) {
    return `Die Option ${JSON.stringify(name)} gibt es in diesem Spiel nicht`;
  }
  if (isAllowedValue(option, value)) {
    return undefined;
  }
  return option.type === "boolean"
    ? `${option.label} ist ein Schalter und nimmt nur true oder false`
    : `${JSON.stringify(value) ?? String(value)} ist für ${option.label} nicht vorgesehen, möglich sind ${option.choices.map((choice) => JSON.stringify(choice.value)).join(", ")}`;
}

export function optionsProblem(options: unknown): string | undefined {
  if (!isRecord(options)) {
    return "options muss ein Objekt aus Namen und Werten sein";
  }
  const names = Object.keys(options);
  if (names.length > maxOptions) {
    return `options hat ${names.length} Einträge, erlaubt sind höchstens ${maxOptions}`;
  }
  for (const name of names) {
    if (!optionNamePattern.test(name) || name in Object.prototype) {
      return `${JSON.stringify(name)} ist kein Name einer Option`;
    }
    const value = options[name];
    const valid =
      typeof value === "boolean" || (typeof value === "number" && Number.isSafeInteger(value)) || (typeof value === "string" && isText(value));
    if (!valid) {
      return `options.${name} muss true, false, eine ganze Zahl oder ein kurzer Text sein`;
    }
  }
  return undefined;
}

export function optionLabel(option: OptionSpec, value: OptionValue): string {
  if (option.type === "boolean") {
    return value === true ? "ja" : "nein";
  }
  return option.choices.find((choice) => choice.value === value)?.label ?? String(value);
}

function isAllowedValue(option: OptionSpec, value: unknown): value is OptionValue {
  if (option.type === "boolean") {
    return typeof value === "boolean";
  }
  return (typeof value === "string" || typeof value === "number") && option.choices.some((choice) => choice.value === value);
}

function isLabel(value: unknown): value is string {
  return typeof value === "string" && value.trim() !== "" && value.length <= maxOptionLabelLength;
}

function isText(value: unknown): value is string {
  return typeof value === "string" && value.trim() !== "" && value.length <= maxOptionTextLength;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
